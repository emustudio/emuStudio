/*
 * debugTableModel.java
 *
 * Created on Pondelok, 2007, marec 26, 16:29
 *
 * KEEP IT SIMPLY STUPID
 */

package emu8;

import javax.swing.table.*;
import javax.swing.*;
import devices.*;
import proc8080.*;
//import java.lang.*;
import java.util.*;

/**
 *
 * @author vbmacher
 */
public class debugTableModel extends AbstractTableModel {
    private Cpu cpu;
    private proc8080.asmCompiler compiler;
    
    private int nextAddress;
    private int lastRow;
    private Locale currentLocale;
    
    /** Creates a new instance of debugTableModel */
    public debugTableModel(Cpu cpu, proc8080.asmCompiler comp, Locale currentLocale) {
        this.cpu = cpu;
        this.compiler = comp;
        lastRow = 0;
        this.currentLocale = currentLocale;
        nextAddress = this.getFirstRowAddress();
    }

    // pocet riadkov
    public int getRowCount() {
        int a = cpu.mem.getSize()-cpu.getPC();
        if (a < 25) return a;
        else return 25;
    }

    public int getColumnCount() {
        return 4;
    }

    public String getColumnName(int col) {
        switch (col) {
            case 0: return "breakpoint";
            case 1: return java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgDebugAddress");
            case 2: return java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgDebugMnemonics");
            case 3: return java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgDebugOpcode");
            default: return "*";
        }
    }
    
    public Class getColumnClass(int columnIndex) {
        if (columnIndex == 0) return java.lang.Boolean.class;
        return java.lang.String.class;
    }
    
    // zisti o kolko adr. buniek sa dozadu posunie adresa aby 6. instrukcia bola na adrese PC
    // tu je bug
    private int getFirstRowAddress() {
        int pc = cpu.getPC();
        int pstart = compiler.getProgramStart();
        int fstInstr = compiler.getFirstInstruction();
        if (pc > pstart) {
            // max 8 instrukcii
            int a = pstart;
            if (pc < a) a = fstInstr;
            if (pc < a) a = 0;
            while ((a < pc) && (pc > a+8)) a = this.compiler.getNextAddress(a);
            return a;
        }
        else return pc;
    }
    
    public int getRowAddress(int rowIndex) {
        if (rowIndex == 0) return this.getFirstRowAddress();
        else if (rowIndex == (lastRow +1)) return nextAddress;
        else { int i = 0, a = 0;
            a = this.getFirstRowAddress();
            for (i = 0; i < rowIndex; i++) a = this.compiler.getNextAddress(a);
            return a;
        }
    }
    
    public Object getValueAt(int rowIndex, int columnIndex) {
        ArrayList instr;
        int addr;
        
        if (rowIndex >= this.getRowCount())  {
            if (columnIndex == 0) return false; else return "";
        }

        if (rowIndex == 0) { nextAddress = this.getFirstRowAddress(); lastRow = 0; }
        else if (rowIndex != (lastRow +1)) {
            // skacem
            int i = 0;
            nextAddress = this.getFirstRowAddress();
            for (i = 0; i < rowIndex; i++) nextAddress = this.compiler.getNextAddress(nextAddress);
            lastRow = i;
        }
        addr = nextAddress;
        try {
            instr = this.compiler.disassembleInstruction(addr);
            nextAddress = Integer.valueOf(instr.get(2).toString());
            lastRow = rowIndex;
            switch (columnIndex) {
                case 0: return cpu.isBreakpoint(addr); // breakpoint
                case 1: return String.format("%Xh", addr); // adresa
                case 2: return String.valueOf(instr.get(0)); // mnemonika
                case 3: return String.valueOf(instr.get(1)); // operacny kod
                default: return "";
            }
        } catch(IndexOutOfBoundsException e) {
            // tu sa dostanem iba v pripade, ak pouzivatel manualne
            // zmenil hodnotu operacnej pamate tak, ze vyjadruje
            // instrukciu s viacerymi bytami, ktore sa uz nezmestili
            // do operacnej pamate
            switch (columnIndex) {
                case 0: return cpu.isBreakpoint(addr); // breakpoint
                case 1: return String.format("%Xh", addr); // adresa
                case 2: return java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgDebugPartiallyInstruction");    // mnemonika
                case 3: return String.format("%X", cpu.mem.getCell(addr)); // operacny kod
                default: return "";
            }
        }
    }
    
    // nastavenie breakpointu
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        if (columnIndex != 0) return;
        int a = getRowAddress(rowIndex);
        if (Boolean.valueOf(aValue.toString()) == true) cpu.setBreakpoint(a);
        else cpu.clearBreakpoint(a);
    }
    
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        if (columnIndex == 0) return true;
        return false;
    }
    
}
