/*
 * memoryTableModel.java
 *
 * Created on Streda, 2007, marec 21, 9:38
 *
 * KEEP IT SIMPLY STUPID
 */

package emu8;

import javax.swing.table.*;
import javax.swing.*;
import devices.*;

/**
 * model pre tabulku operacnej pamate
 * podporuje strankovanie (zobrazuje len urcity pocet riadkov na stranku) - kvoli zvyseniu
 * rychlosti
 *
 * @author vbmacher
 */
public class memoryTableModel extends AbstractTableModel {
    private Memory mem_data;
    private int currentPage;

    /** Creates a new instance of memoryTableModel */
    public memoryTableModel(Memory mem) {
        mem_data = mem;
        currentPage = 0;
    }

    // pocet riadkov
    public int getRowCount() {
        return 16; //mem_data.getSize() / 16;
    }

    // od 00-FF
    public int getColumnCount() {
        return 16;
    }

    public String getColumnName(int col) {
        return String.format("0%1$Xh", col);
    }
    
    public Object getValueAt(int rowIndex, int columnIndex) {
        // data
        int pos = getRowCount() * getColumnCount() * currentPage + rowIndex * 16 + columnIndex;
        return String.format("%X", mem_data.getCell(pos));
    }
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        int pos = getRowCount() * getColumnCount() * currentPage + rowIndex * 16 + columnIndex;
        try {
            mem_data.setCell(pos,Short.decode(String.valueOf(aValue)));
            fireTableCellUpdated(rowIndex, columnIndex);
        } catch (NumberFormatException e) {}
    }
    
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }
    
    /* strankovanie */
    public void setPage(int page) throws IndexOutOfBoundsException {
        if (page >= getPageCount() || page < 0) throw new IndexOutOfBoundsException();
        currentPage = page;
        fireTableDataChanged();
    }
    
    public int getPage() {
        return currentPage;
    }
    
    public int getPageCount() {
        return mem_data.getSize()/256;
    }
}
