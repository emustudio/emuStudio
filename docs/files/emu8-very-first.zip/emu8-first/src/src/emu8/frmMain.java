/*
 * frmMain.java
 *
 * Created on Nede�a, 2007, marec 11, 17:57
 *
 * KEEP IT STUPID SIMPLE
 *
 */

package emu8;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.filechooser.*;
import javax.swing.table.*;
import javax.swing.event.*;
import javax.swing.text.*;
import javax.swing.table.TableModel;
import java.io.*;
import java.util.*;

import proc8080.*;

/**
 *
 * @author  vbmacher
 */
public class frmMain extends javax.swing.JFrame implements TableModelListener {
    private java.io.File srcFile;
    private boolean savedFile;
    private Cpu cpu;
    private proc8080.asmCompiler compiler;
    private memoryTableModel memModel;
    private debugTableModel debModel;
    private Locale currentLocale;
    
    /** Creates new form frmMain */
    public frmMain() {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } 
        catch (UnsupportedLookAndFeelException e) {}
        catch (ClassNotFoundException e) {}
        catch (InstantiationException e) {}
        catch (IllegalAccessException e) {}

        /* ZDROJOVY KOD */
        cpu = new Cpu();
        this.memModel = new memoryTableModel(cpu.mem);
        this.srcFile = null;
        savedFile = true;
        currentLocale = new Locale("sk", "SK");
        initComponents();

        Dimension us = this.getSize(), them = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((them.width - us.width) / 2, (them.height - us.height) / 2);
        
        jRadioButtonMenuItemSlovak.setSelected(true);
        jRadioButtonMenuItemEnglish.setSelected(false);
        
        compiler = new proc8080.asmCompiler(cpu.mem, txtSource, txtCompiler,true);

        jTabbedPane1.setEnabledAt(0, true);
        jTabbedPane1.setEnabledAt(1, false);

        txtSource.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { savedFile = false; jTabbedPane1.setEnabledAt(1, false); jTabbedPane1.setSelectedIndex(0); }
            public void removeUpdate(DocumentEvent e) { savedFile = false; jTabbedPane1.setEnabledAt(1, false); jTabbedPane1.setSelectedIndex(0); }
            public void changedUpdate(DocumentEvent e) {}
        });
        
        /* EMULATOR */
        this.debModel = new debugTableModel(cpu,this.compiler,currentLocale);
        emuDebug.setModel(this.debModel);
        emuDebug.setDefaultRenderer(Object.class, new DebugCellRenderer());
        emuDebug.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        emuMemory.setDefaultRenderer(Object.class, new MemCellRenderer());
        emuMemory.getModel().addTableModelListener(this);
        emuMemory.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        memModel.addTableModelListener(new TableModelListener() {
            public void tableChanged(TableModelEvent e) {
                SpinnerNumberModel dateModel = (SpinnerNumberModel)spnPage.getModel();
                dateModel.setValue(memModel.getPage());
                emuDebug.repaint();
            }
        });
        lblPageCount.setText(String.valueOf(memModel.getPageCount()));
        
        spnPage.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                SpinnerNumberModel dateModel = (SpinnerNumberModel)spnPage.getModel();
                Integer i = (Integer)dateModel.getValue();
                memModel.setPage(i.intValue());
            }
        });
        
        spnClock.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                SpinnerNumberModel dateModel = (SpinnerNumberModel)spnClock.getModel();
                Integer i = (Integer)dateModel.getValue();
                cpu.setCPUClock(i.intValue());
                lblFreq.setText(String.valueOf(cpu.getCPUFreq())+" kHz");
            }
        });
        
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                int sel;
                if (savedFile == false) {
                    sel = JOptionPane.showConfirmDialog(null,
                            java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgSaveConfirm"),
                            java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgExitSaveConfirmTitle"),
                            JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if (sel == JOptionPane.CANCEL_OPTION) return;
                    if (sel == JOptionPane.YES_OPTION) jMenuItemSaveActionPerformed(null);
                }
                dispose();
                System.exit(0); //calling the method is a must
            }
        });
    }
    
    /* ZDROJOVY KOD */
    
    /* implementacia zobrazovania cisla riadkov */
    class NumberedEditorKit extends StyledEditorKit {
        public ViewFactory getViewFactory() {
            return new NumberedViewFactory();
        }
    }

    /* implementacia zobrazovania cisla riadkov */
    class NumberedViewFactory implements ViewFactory {
        public View create(Element elem) {
            String kind = elem.getName();
            if (kind != null) {
                if (kind.equals(AbstractDocument.ContentElementName)) return new LabelView(elem);
                else if (kind.equals(AbstractDocument.ParagraphElementName)) return new NumberedParagraphView(elem);
                else if (kind.equals(AbstractDocument.SectionElementName)) return new BoxView(elem, View.Y_AXIS);
                else if (kind.equals(StyleConstants.ComponentElementName)) return new ComponentView(elem);
                else if (kind.equals(StyleConstants.IconElementName)) return new IconView(elem);
            }
            // default to text display
            return new LabelView(elem);
        }
    }

    /* implementacia zobrazovania cisla riadkov */
    class NumberedParagraphView extends ParagraphView {
        public final short NUMBERS_WIDTH = 20; // bolo static
        private Font fontUsed;

        public NumberedParagraphView(Element e) {
            super(e);
            short top = 0, left = 0, bottom = 0, right = 0;
            super.setFirstLineIndent(NUMBERS_WIDTH);
            this.setInsets(top, left, bottom, right);
            fontUsed = new Font("monospaced", Font.PLAIN, 12);
        }

        protected void setInsets(short top, short left, short bottom, short right) {
            super.setInsets(top,(short)(left+NUMBERS_WIDTH), bottom,right);
        }
        public void changedUpdate(DocumentEvent changes, Shape a, ViewFactory f) {}
        
        // n je cislo riadka
        public void paintChild(Graphics g, Rectangle r, int n) {
            if (r.x < this.getLeftInset()) r.x = this.getLeftInset();
            super.paintChild(g, r, n);
            int previousLineCount = getPreviousLineCount();
            int numberX = r.x - getLeftInset();
            int numberY = r.y + r.height - 5;
            g.setFont(this.fontUsed);
            g.setColor(Color.RED);
//            g.drawString(Integer.toString(previousLineCount + n + 1), numberX, numberY);
            if (n == 0) g.drawString(Integer.toString(previousLineCount + 1), numberX, numberY);
        }

        public int getPreviousLineCount() {
            int lineCount = 0;
            View parent = this.getParent();
            int count = parent.getViewCount();
            for (int i = 0; i < count; i++)
                if (parent.getView(i) == this) break;
                else lineCount++;
                //else lineCount += parent.getView(i).getViewCount();
            return lineCount;
        }
    }

    /* vseobecny suborovy (priponovy) filter */
    private class usefulFilter extends javax.swing.filechooser.FileFilter {
        private String[] exts;
        private String desc;
        
        public void addExtension(String ext) {
            int l=0;
            String[] tmp;
            if (exts != null) l = exts.length;
            tmp = new String[l+1];
            if (exts != null)
                System.arraycopy(exts,0,tmp,0,l);
            tmp[l] = ext;
            exts = tmp;
        }
        
        public String getFirstExtension() {
            if (exts != null) return exts[0];
            return null;
        }
        
        public boolean accept(java.io.File f) {
            if (f.isDirectory()) return true;
            String ext = this.getExtension(f);
            if (ext != null) {
                for (int i = 0; i < exts.length; i++)
                    if (exts[i].equals(ext) || exts[i] == "*") return true;
            } else {
                for (int i = 0; i < exts.length; i++)
                    if (exts[i] == "*") return true;
            }
            return false;
        }
    
        public String getExtension(java.io.File f) {
            String ext = null;
            String s = f.getName();
            int i = s.lastIndexOf('.');
            if (i > 0 &&  i < s.length() - 1) {
                ext = s.substring(i+1).toLowerCase();
            }
            return ext;
        }
        
        public String getDescription() {
            return desc;
        }
        
        public void setDescription(String des) {
            desc = des;
        }
    }
    
    /* EMULATOR */
    
    private void updateMemoryInfo(int value) {
        char v = (char)(value & 0xFF);
        txtMemValueDEC.setText(Integer.toString(value));
        txtMemValueHEX.setText(Integer.toHexString(value).toUpperCase());
        txtMemValueBIN.setText(Integer.toBinaryString(value));
        txtMemValueOCT.setText(Integer.toOctalString(value));
        txtMemValueChar.setText(String.valueOf(v));
    }
    
    public void tableChanged(TableModelEvent e) {
        int row = e.getFirstRow();
        int column = e.getColumn();
        
        if (emuMemory.isCellSelected(row, column) == false) return;
        
        int address = memModel.getRowCount() * memModel.getColumnCount() * memModel.getPage()+ row * 16 + column;

        TableModel model = (TableModel)e.getSource();
        int data = Integer.valueOf(model.getValueAt(row, column).toString(),16);
        txtAddress.setText(Integer.toHexString(address).toUpperCase()+"h");
        updateMemoryInfo(data);
    }

    class MemRowHeaderRenderer extends JLabel implements ListCellRenderer {
        MemRowHeaderRenderer(JTable table) {
            JTableHeader header = table.getTableHeader();
            setOpaque(true);
            setBorder(UIManager.getBorder("TableHeader.cellBorder"));
            setHorizontalAlignment(CENTER);
            setForeground(header.getForeground());
            setBackground(header.getBackground());
            setFont(header.getFont());
        }
  
        public Component getListCellRendererComponent( JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }
    
    /* farebnost a zobrazenie buniek v operacnej pamati */
    public class MemCellRenderer extends JLabel implements TableCellRenderer {
        private JList rowHeader;
        String adresses[];
        private int currentPage;

        public MemCellRenderer() {
            super();
            setOpaque(true);
            currentPage = memModel.getPage();
            adresses = new String[memModel.getRowCount()];
            for (int i = 0; i < adresses.length; i++)
                adresses[i] = String.format("%1$4Xh",
                                16*i+memModel.getColumnCount()*memModel.getRowCount()*currentPage);
            rowHeader = new JList(adresses); rowHeader.setFixedCellWidth(40); rowHeader.setFixedCellHeight(emuMemory.getRowHeight());
            rowHeader.setCellRenderer(new MemRowHeaderRenderer(emuMemory));
            setHorizontalAlignment(CENTER); emuMemoryPane.setRowHeaderView(rowHeader);
        }
        
        private void remakeAdresses() {
            if (currentPage == memModel.getPage()) return;
            currentPage = memModel.getPage();
            adresses = new String[memModel.getRowCount()];
            for (int i = 0; i < adresses.length; i++)
                adresses[i] = String.format("%1$4Xh",16*i+memModel.getColumnCount()*memModel.getRowCount()*currentPage);
            rowHeader.setListData(adresses);
        }

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (isSelected) {
                this.setBackground(emuMemory.getSelectionBackground());
                this.setForeground(emuMemory.getSelectionForeground());
            } else { this.setBackground(Color.WHITE); this.setForeground(Color.BLACK); }
            remakeAdresses();
            setText(value.toString());
            return this;
        }
    }
    
    /* farebnost a zobrazenie buniek v tabulke ladenia programu */
    public class DebugCellRenderer extends JLabel implements TableCellRenderer {
        public DebugCellRenderer() {  super(); setOpaque(true); }
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (debModel.getRowAddress(row) == cpu.getPC()) {
                this.setBackground(Color.RED); this.setForeground(Color.WHITE);
            } else { this.setBackground(Color.WHITE); this.setForeground(Color.BLACK);  }
            setText(value.toString());
            return this;
        }
    }
    
    // nastavi listenery zmeny vnutorneho stavu CPU, ze sa to prejavi aj na obrazovke
    private void enableCPUListeners() {
        cpu.addCpuChangeStateListener(new Cpu.cpuChangeStateListener() {
            public void cpuPC_change(Cpu.cpuChangeStateEvent evt) { emuDebug.repaint(); }
            public void cpuSP_change(Cpu.cpuChangeStateEvent evt) { txtRegSP.setText(Integer.toHexString((int)cpu.getRegSP())); }
            public void cpuB_change(Cpu.cpuChangeStateEvent evt) {
                txtRegB.setText(Integer.toHexString((int)cpu.getRegB()));
                txtRegBC.setText(Integer.toHexString((int)((cpu.getRegB() << 8) | cpu.getRegC())));
            }
            public void cpuC_change(Cpu.cpuChangeStateEvent evt) {
                txtRegC.setText(Integer.toHexString((int)cpu.getRegC()));
                txtRegBC.setText(Integer.toHexString((int)((cpu.getRegB() << 8) | cpu.getRegC())));
            }
            public void cpuD_change(Cpu.cpuChangeStateEvent evt) {
                txtRegD.setText(Integer.toHexString((int)cpu.getRegD()));
                txtRegDE.setText(Integer.toHexString((int)((cpu.getRegD() << 8) | cpu.getRegE())));
            }
            public void cpuE_change(Cpu.cpuChangeStateEvent evt) {
                txtRegE.setText(Integer.toHexString((int)cpu.getRegE()));
                txtRegDE.setText(Integer.toHexString((int)((cpu.getRegD() << 8) | cpu.getRegE())));
            }
            public void cpuH_change(Cpu.cpuChangeStateEvent evt) {
                txtRegH.setText(Integer.toHexString((int)cpu.getRegH()));
                txtRegHL.setText(Integer.toHexString((int)((cpu.getRegH() << 8) | cpu.getRegL())));
            }
            public void cpuL_change(Cpu.cpuChangeStateEvent evt) {
                txtRegL.setText(Integer.toHexString((int)cpu.getRegL()));
                txtRegHL.setText(Integer.toHexString((int)((cpu.getRegH() << 8) | cpu.getRegL())));
            }
            public void cpuA_change(Cpu.cpuChangeStateEvent evt) { txtRegA.setText(Integer.toHexString((int)cpu.getRegA())); }
            public void cpuPSW_change(Cpu.cpuChangeStateEvent evt) {
                txtFR.setText(Integer.toHexString((int)cpu.getFR()));
                if (cpu.getFlag(cpu.flagS) == true) cmbFlagS.setSelectedIndex(1);
                else cmbFlagS.setSelectedIndex(0);
                if (cpu.getFlag(cpu.flagZ) == true) cmbFlagZ.setSelectedIndex(1);
                else cmbFlagZ.setSelectedIndex(0);
                if (cpu.getFlag(cpu.flagAC) == true) cmbFlagAC.setSelectedIndex(1);
                else cmbFlagAC.setSelectedIndex(0);
                if (cpu.getFlag(cpu.flagP) == true) cmbFlagP.setSelectedIndex(1);
                else cmbFlagP.setSelectedIndex(0);
                if (cpu.getFlag(cpu.flagC) == true) cmbFlagC.setSelectedIndex(1);
                else cmbFlagC.setSelectedIndex(0);
            }
            public void cpuMem_change(Cpu.cpuChangeStateEvent evt) { emuMemory.repaint(); emuDebug.repaint(); }
            public void cpuStopped(Cpu.cpuChangeStateEvent evt) {
                btnStop.setEnabled(false);
                if (cpu.getReasonStopped() == Cpu.rsnEnum.reasonBreakpoint) {
                    btnStart.setEnabled(true); btnStep.setEnabled(true);
                } else {
                    btnStart.setEnabled(false); btnStep.setEnabled(false);
                }
                btnBack.setEnabled(true); btnBegin.setEnabled(true);
                switch (cpu.getReasonStopped().ordinal()) {
                    case 0: lblReasonStopped.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgRsnNormal")); break;
                    case 1: lblReasonStopped.setText("breakpoint"); break;
                    case 2: lblReasonStopped.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgRsnBadAddress")); break;
                    case 3: lblReasonStopped.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgRsnBadInstruction")); break;
                }
                lblStates.setText(String.valueOf(cpu.getStatesExecuted()));
                lblDuration.setText(String.valueOf(cpu.getTrueDuration())+" ms");
                lblTheoretical.setText(String.valueOf(cpu.getTheoreticalDuration())+" ms");
            }
            public void cpuRunned(Cpu.cpuChangeStateEvent evt) {
                btnStop.setEnabled(true); btnBack.setEnabled(false);
                btnStart.setEnabled(false); btnStep.setEnabled(false);
                btnBegin.setEnabled(false);
                lblReasonStopped.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgRsnRuns"));
            }
        });
    }
    
    public void enableEmulator() {
        txtRegA.setEditable(true); txtRegB.setEditable(true); txtRegC.setEditable(true); txtRegD.setEditable(true); txtRegE.setEditable(true);
        txtRegH.setEditable(true); txtRegL.setEditable(true); txtRegSP.setEditable(true); cmbFlagS.setEnabled(true); cmbFlagP.setEnabled(true);
        cmbFlagZ.setEnabled(true); cmbFlagC.setEnabled(true); cmbFlagAC.setEnabled(true); spnClock.setEnabled(true); emuMemory.setEnabled(true);
        btnFindAddress.setEnabled(true); spnPage.setEnabled(true);
    }
    
    public void disableEmulator() {
        txtRegA.setEditable(false); txtRegB.setEditable(false); txtRegC.setEditable(false); txtRegD.setEditable(false); txtRegE.setEditable(false);
        txtRegH.setEditable(false); txtRegL.setEditable(false); txtRegSP.setEditable(false); cmbFlagS.setEnabled(false); cmbFlagP.setEnabled(false);
        cmbFlagZ.setEnabled(false); cmbFlagC.setEnabled(false); cmbFlagAC.setEnabled(false); spnClock.setEnabled(false); emuMemory.setEnabled(false);
        btnFindAddress.setEnabled(false); spnPage.setEnabled(false);
    }
    
    /* po zmene jazyka sa musia pre-zobrazit vsetky napisy */
    public void updateLanguageStrings() {
        jMenuFile.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuFile"));
        jMenuEdit.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuEdit"));
        jMenuLanguage.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuLanguage"));
        jMenuHelp.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuHelp"));
        jMenuItemNew.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuFileNew"));
        jMenuItemOpen.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuFileOpen"));
        jMenuItemSave.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuFileSave"));
        jMenuItemSaveAs.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuFileSaveAs"));
        jMenuItemExit.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuFileExit"));
        jMenuItemCut.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuEditCut"));
        jMenuItemCopy.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuEditCopy"));
        jMenuItemPaste.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuEditPaste"));
        jMenuItemCompile.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuEditCompile"));
        jRadioButtonMenuItemEnglish.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuLanguageEnglish"));
        jRadioButtonMenuItemSlovak.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuLanguageSlovak"));
        jMenuItemAbout.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuHelpAbout"));
        jButton1.setToolTipText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("toolTipFileNew"));
        jButton2.setToolTipText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("toolTipFileOpen"));
        jButton3.setToolTipText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("toolTipFileSave"));
        jButton10.setToolTipText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuEditCut"));
        jButton11.setToolTipText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuEditCopy"));
        jButton12.setToolTipText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("mnuEditPaste"));
        jButton4.setToolTipText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("toolTipEditCompile"));
        jTabbedPane1.setTitleAt(0,java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("tabSourceCode"));
        jTabbedPane1.setTitleAt(1,java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("tabEmulator"));
        lblProcessor.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("txtProcessor"));
        btnBegin.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("btnBegin"));
        btnBack.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("btnBack"));
        btnStop.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("btnStop"));
        btnStart.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("btnStart"));
        btnStep.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("btnStep"));
        btnJump.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("btnJump"));
        lblFrequency.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("txtFrequency"));
        lblImpulse.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("txtImpulse"));
        javax.swing.border.TitledBorder b = (javax.swing.border.TitledBorder)emuDebugPane.getBorder(); b.setTitle(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("paneDebug"));
        b = (javax.swing.border.TitledBorder)emuMemoryPane.getBorder(); b.setTitle(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("paneMemory"));
        b = (javax.swing.border.TitledBorder)emuInfoPane.getBorder(); b.setTitle(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("paneInfo"));
        b = (javax.swing.border.TitledBorder)paneInfoBreak.getBorder(); b.setTitle(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("paneBreakpoint"));
        b = (javax.swing.border.TitledBorder)paneInfoRegisters.getBorder(); b.setTitle(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("paneRegisters"));
        b = (javax.swing.border.TitledBorder)paneInfoMemoryValue.getBorder(); b.setTitle(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("paneMemoryValue"));
        jLabel22.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("txtBreakpointReason"));
        jLabel23.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("txtStatesCount"));
        jLabel24.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("txtDuration"));
        jLabel26.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("txtTheoretical"));
        lblPSW.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("txtFlags"));
        jLabel1.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("txtProcessorFlags"));
        jLabel9.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("txtAddress"));
        jLabel10.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("txtValue"));
        jLabel15.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("txtMemoryPageNumber"));
        jLabel16.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("txtMemoryPageCount"));
        btnFindAddress.setText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("txtFindAddress"));
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmMain().setVisible(true);
            }
        });
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtSource = new javax.swing.JTextPane();
        jToolBar1 = new javax.swing.JToolBar();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JSeparator();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jSeparator4 = new javax.swing.JSeparator();
        jButton4 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtCompiler = new javax.swing.JTextArea();
        lblProcessor = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        emuDebugPane = new javax.swing.JScrollPane();
        emuDebug = new javax.swing.JTable();
        emuMemoryPane = new javax.swing.JScrollPane();
        emuMemory = new javax.swing.JTable();
        emuInfoPane = new javax.swing.JPanel();
        paneInfoBreak = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        lblStates = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        lblDuration = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        lblTheoretical = new javax.swing.JLabel();
        lblReasonStopped = new javax.swing.JLabel();
        paneInfoRegisters = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        txtFR = new javax.swing.JTextField();
        lblPSW = new javax.swing.JLabel();
        cmbFlagC = new javax.swing.JComboBox();
        cmbFlagZ = new javax.swing.JComboBox();
        cmbFlagAC = new javax.swing.JComboBox();
        lblFlag2 = new javax.swing.JLabel();
        lblFlag4 = new javax.swing.JLabel();
        lblFlag1 = new javax.swing.JLabel();
        cmbFlagS = new javax.swing.JComboBox();
        cmbFlagP = new javax.swing.JComboBox();
        lblFlag3 = new javax.swing.JLabel();
        lblFlag0 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtRegHL = new javax.swing.JTextField();
        txtRegDE = new javax.swing.JTextField();
        txtRegBC = new javax.swing.JTextField();
        txtRegSP = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtRegL = new javax.swing.JTextField();
        txtRegE = new javax.swing.JTextField();
        txtRegC = new javax.swing.JTextField();
        lblReg2 = new javax.swing.JLabel();
        lblReg4 = new javax.swing.JLabel();
        lblReg6 = new javax.swing.JLabel();
        txtRegH = new javax.swing.JTextField();
        txtRegD = new javax.swing.JTextField();
        txtRegB = new javax.swing.JTextField();
        lblReg0 = new javax.swing.JLabel();
        lblReg1 = new javax.swing.JLabel();
        lblReg3 = new javax.swing.JLabel();
        lblReg5 = new javax.swing.JLabel();
        txtRegA = new javax.swing.JTextField();
        paneInfoMemoryValue = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        txtAddress = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtMemValueDEC = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtMemValueBIN = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtMemValueHEX = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtMemValueOCT = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txtMemValueChar = new javax.swing.JTextField();
        jToolBar2 = new javax.swing.JToolBar();
        btnReset = new javax.swing.JButton();
        btnBegin = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        btnStop = new javax.swing.JButton();
        btnStart = new javax.swing.JButton();
        btnStep = new javax.swing.JButton();
        btnJump = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        lblFrequency = new javax.swing.JLabel();
        lblFreq = new javax.swing.JLabel();
        jSeparator10 = new javax.swing.JSeparator();
        lblImpulse = new javax.swing.JLabel();
        spnClock = new javax.swing.JSpinner();
        jToolBar3 = new javax.swing.JToolBar();
        jLabel15 = new javax.swing.JLabel();
        spnPage = new javax.swing.JSpinner();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel16 = new javax.swing.JLabel();
        lblPageCount = new javax.swing.JLabel();
        jSeparator6 = new javax.swing.JSeparator();
        btnFindAddress = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenuFile = new javax.swing.JMenu();
        jMenuItemNew = new javax.swing.JMenuItem();
        jMenuItemOpen = new javax.swing.JMenuItem();
        jSeparator8 = new javax.swing.JSeparator();
        jMenuItemSave = new javax.swing.JMenuItem();
        jMenuItemSaveAs = new javax.swing.JMenuItem();
        jSeparator7 = new javax.swing.JSeparator();
        jMenuItemExit = new javax.swing.JMenuItem();
        jMenuEdit = new javax.swing.JMenu();
        jMenuItemCut = new javax.swing.JMenuItem();
        jMenuItemCopy = new javax.swing.JMenuItem();
        jMenuItemPaste = new javax.swing.JMenuItem();
        jSeparator9 = new javax.swing.JSeparator();
        jMenuItemCompile = new javax.swing.JMenuItem();
        jMenuLanguage = new javax.swing.JMenu();
        jRadioButtonMenuItemEnglish = new javax.swing.JRadioButtonMenuItem();
        jRadioButtonMenuItemSlovak = new javax.swing.JRadioButtonMenuItem();
        jMenuHelp = new javax.swing.JMenu();
        jMenuItemAbout = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("EMU8 Studio");
        txtSource.setFont(new java.awt.Font("Courier New", 0, 14));
        txtSource.setEditorKit(new NumberedEditorKit());
        jScrollPane1.setViewportView(txtSource);

        jToolBar1.setFloatable(false);
        jToolBar1.setRollover(true);
        jToolBar1.setPreferredSize(new java.awt.Dimension(305, 60));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/new.gif")));
        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale); // NOI18N
        jButton1.setToolTipText(bundle.getString("toolTipFileNew")); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jToolBar1.add(jButton1);

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/open.gif")));
        jButton2.setToolTipText(bundle.getString("toolTipFileOpen")); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jToolBar1.add(jButton2);

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/save.gif")));
        jButton3.setToolTipText(bundle.getString("toolTipFileSave")); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jToolBar1.add(jButton3);

        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator3.setMaximumSize(new java.awt.Dimension(10, 32767));
        jSeparator3.setMinimumSize(new java.awt.Dimension(10, 10));
        jSeparator3.setPreferredSize(new java.awt.Dimension(10, 10));
        jToolBar1.add(jSeparator3);

        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/cut.gif")));
        jButton10.setToolTipText(bundle.getString("mnuEditCut")); // NOI18N
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jToolBar1.add(jButton10);

        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/copy.gif")));
        jButton11.setToolTipText(bundle.getString("mnuEditCopy")); // NOI18N
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jToolBar1.add(jButton11);

        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/paste.gif")));
        jButton12.setToolTipText(bundle.getString("mnuEditPaste")); // NOI18N
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jToolBar1.add(jButton12);

        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator4.setMaximumSize(new java.awt.Dimension(10, 32767));
        jSeparator4.setMinimumSize(new java.awt.Dimension(10, 10));
        jSeparator4.setPreferredSize(new java.awt.Dimension(10, 10));
        jToolBar1.add(jSeparator4);

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/compile.gif")));
        jButton4.setToolTipText(bundle.getString("toolTipEditCompile")); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jToolBar1.add(jButton4);

        txtCompiler.setBackground(new java.awt.Color(204, 204, 204));
        txtCompiler.setColumns(20);
        txtCompiler.setEditable(false);
        txtCompiler.setFont(new java.awt.Font("Courier New", 0, 12));
        txtCompiler.setRows(5);
        txtCompiler.setMargin(new java.awt.Insets(5, 10, 1, 1));
        jScrollPane3.setViewportView(txtCompiler);

        lblProcessor.setText(bundle.getString("txtProcessor")); // NOI18N

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel18.setText("Intel 8080A");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.DEFAULT_SIZE, 778, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 788, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblProcessor)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel18)
                .addContainerGap(655, Short.MAX_VALUE))
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 788, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblProcessor)
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE)
                .addContainerGap())
        );
        jTabbedPane1.addTab(bundle.getString("tabSourceCode"), jPanel1); // NOI18N

        emuDebugPane.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), bundle.getString("paneDebug"), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N
        emuDebug.setSelectionBackground(new java.awt.Color(255, 255, 255));
        emuDebug.setSelectionForeground(new java.awt.Color(0, 0, 0));
        emuDebugPane.setViewportView(emuDebug);

        emuMemoryPane.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), bundle.getString("paneMemory"), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N
        emuMemory.setFont(new java.awt.Font("Courier New", 0, 12));
        emuMemory.setModel(this.memModel);
        emuMemory.setCellSelectionEnabled(true);
        emuMemory.setFocusCycleRoot(true);
        emuMemory.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                emuMemoryMouseClicked(evt);
            }
        });

        emuMemoryPane.setViewportView(emuMemory);

        emuInfoPane.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), bundle.getString("paneInfo"), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N
        paneInfoBreak.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        paneInfoBreak.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 153), 1, true), bundle.getString("paneBreakpoint"), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(102, 102, 102))); // NOI18N
        jLabel22.setText(bundle.getString("txtBreakpointReason")); // NOI18N
        paneInfoBreak.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        jLabel23.setText(bundle.getString("txtStatesCount")); // NOI18N
        paneInfoBreak.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, -1));

        lblStates.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblStates.setText("0");
        paneInfoBreak.add(lblStates, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, -1, -1));

        jLabel24.setText(bundle.getString("txtDuration")); // NOI18N
        paneInfoBreak.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, -1, -1));

        lblDuration.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblDuration.setText("0 ms");
        paneInfoBreak.add(lblDuration, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, -1, -1));

        jLabel26.setText(bundle.getString("txtTheoretical")); // NOI18N
        paneInfoBreak.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        lblTheoretical.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblTheoretical.setText("0 ms");
        paneInfoBreak.add(lblTheoretical, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 80, -1, -1));

        lblReasonStopped.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblReasonStopped.setForeground(new java.awt.Color(0, 102, 0));
        lblReasonStopped.setText("normal");
        paneInfoBreak.add(lblReasonStopped, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, -1, -1));

        paneInfoRegisters.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        paneInfoRegisters.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 153), 1, true), bundle.getString("paneRegisters"), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(102, 102, 102))); // NOI18N
        jLabel19.setText("(hex)");
        paneInfoRegisters.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 120, -1, -1));

        txtFR.setEditable(false);
        txtFR.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtFR.setText("00");
        txtFR.setPreferredSize(new java.awt.Dimension(60, 20));
        paneInfoRegisters.add(txtFR, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 70, -1));

        lblPSW.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblPSW.setText(bundle.getString("txtFlags")); // NOI18N
        paneInfoRegisters.add(lblPSW, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        cmbFlagC.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "0", "1" }));
        paneInfoRegisters.add(cmbFlagC, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 200, 40, -1));

        cmbFlagZ.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "0", "1" }));
        paneInfoRegisters.add(cmbFlagZ, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, 40, -1));

        cmbFlagAC.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "0", "1" }));
        paneInfoRegisters.add(cmbFlagAC, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 170, 40, -1));

        lblFlag2.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblFlag2.setText("AC");
        paneInfoRegisters.add(lblFlag2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 170, -1, -1));

        lblFlag4.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblFlag4.setText("C");
        paneInfoRegisters.add(lblFlag4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 200, -1, -1));

        lblFlag1.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblFlag1.setText("Z");
        paneInfoRegisters.add(lblFlag1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 170, -1, -1));

        cmbFlagS.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "0", "1" }));
        paneInfoRegisters.add(cmbFlagS, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 170, 40, -1));

        cmbFlagP.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "0", "1" }));
        cmbFlagP.setPreferredSize(new java.awt.Dimension(40, 22));
        paneInfoRegisters.add(cmbFlagP, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, -1, -1));

        lblFlag3.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblFlag3.setText("P");
        paneInfoRegisters.add(lblFlag3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, -1, -1));

        lblFlag0.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblFlag0.setText("S");
        paneInfoRegisters.add(lblFlag0, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        jLabel1.setText(bundle.getString("txtProcessorFlags")); // NOI18N
        paneInfoRegisters.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, -1, -1));

        txtRegHL.setEditable(false);
        txtRegHL.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtRegHL.setText("00");
        txtRegHL.setPreferredSize(new java.awt.Dimension(40, 20));
        paneInfoRegisters.add(txtRegHL, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 90, -1, -1));

        txtRegDE.setEditable(false);
        txtRegDE.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtRegDE.setText("00");
        txtRegDE.setPreferredSize(new java.awt.Dimension(40, 20));
        paneInfoRegisters.add(txtRegDE, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 70, -1, -1));

        txtRegBC.setEditable(false);
        txtRegBC.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtRegBC.setText("00");
        txtRegBC.setPreferredSize(new java.awt.Dimension(40, 20));
        paneInfoRegisters.add(txtRegBC, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 50, -1, -1));

        txtRegSP.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtRegSP.setText("00");
        txtRegSP.setPreferredSize(new java.awt.Dimension(40, 20));
        paneInfoRegisters.add(txtRegSP, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 30, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel7.setText("SP");
        paneInfoRegisters.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 30, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel2.setText("BC");
        paneInfoRegisters.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel3.setText("DE");
        paneInfoRegisters.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel4.setText("HL");
        paneInfoRegisters.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 90, -1, -1));

        txtRegL.setText("0");
        txtRegL.setPreferredSize(new java.awt.Dimension(40, 20));
        paneInfoRegisters.add(txtRegL, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 90, -1, -1));

        txtRegE.setText("0");
        txtRegE.setPreferredSize(new java.awt.Dimension(40, 20));
        paneInfoRegisters.add(txtRegE, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 70, -1, -1));

        txtRegC.setText("0");
        txtRegC.setPreferredSize(new java.awt.Dimension(40, 20));
        paneInfoRegisters.add(txtRegC, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 50, -1, -1));

        lblReg2.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblReg2.setText("C");
        paneInfoRegisters.add(lblReg2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, -1, -1));

        lblReg4.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblReg4.setText("E");
        paneInfoRegisters.add(lblReg4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, -1, -1));

        lblReg6.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblReg6.setText("L");
        paneInfoRegisters.add(lblReg6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 90, -1, -1));

        txtRegH.setText("0");
        txtRegH.setPreferredSize(new java.awt.Dimension(40, 20));
        paneInfoRegisters.add(txtRegH, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, -1, -1));

        txtRegD.setText("0");
        txtRegD.setPreferredSize(new java.awt.Dimension(40, 20));
        paneInfoRegisters.add(txtRegD, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, -1, -1));

        txtRegB.setText("0");
        txtRegB.setPreferredSize(new java.awt.Dimension(40, 20));
        paneInfoRegisters.add(txtRegB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, -1, -1));

        lblReg0.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblReg0.setText("A");
        paneInfoRegisters.add(lblReg0, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));

        lblReg1.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblReg1.setText("B");
        paneInfoRegisters.add(lblReg1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        lblReg3.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblReg3.setText("D");
        paneInfoRegisters.add(lblReg3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        lblReg5.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblReg5.setText("H");
        paneInfoRegisters.add(lblReg5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, -1));

        txtRegA.setText("0");
        txtRegA.setPreferredSize(new java.awt.Dimension(40, 20));
        paneInfoRegisters.add(txtRegA, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, -1, -1));

        paneInfoMemoryValue.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 153), 1, true), bundle.getString("paneMemoryValue"), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(102, 102, 102))); // NOI18N
        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel9.setText(bundle.getString("txtAddress")); // NOI18N

        txtAddress.setEditable(false);
        txtAddress.setText("0000h");

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel10.setText(bundle.getString("txtValue")); // NOI18N

        txtMemValueDEC.setEditable(false);
        txtMemValueDEC.setText("0");

        jLabel11.setText("(dec)");

        txtMemValueBIN.setEditable(false);
        txtMemValueBIN.setText("0");

        jLabel12.setText("(bin)");

        txtMemValueHEX.setEditable(false);
        txtMemValueHEX.setText("0");

        jLabel13.setText("(hex)");

        txtMemValueOCT.setEditable(false);
        txtMemValueOCT.setText("0");

        jLabel14.setText("(oct)");

        txtMemValueChar.setEditable(false);

        javax.swing.GroupLayout paneInfoMemoryValueLayout = new javax.swing.GroupLayout(paneInfoMemoryValue);
        paneInfoMemoryValue.setLayout(paneInfoMemoryValueLayout);
        paneInfoMemoryValueLayout.setHorizontalGroup(
            paneInfoMemoryValueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paneInfoMemoryValueLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(paneInfoMemoryValueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel10)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(paneInfoMemoryValueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(txtMemValueChar, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtMemValueOCT, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtMemValueHEX, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtMemValueBIN, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtMemValueDEC, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtAddress, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(paneInfoMemoryValueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13)
                    .addComponent(jLabel14))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        paneInfoMemoryValueLayout.setVerticalGroup(
            paneInfoMemoryValueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paneInfoMemoryValueLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(paneInfoMemoryValueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(paneInfoMemoryValueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtMemValueDEC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(paneInfoMemoryValueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMemValueBIN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(paneInfoMemoryValueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMemValueHEX, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(paneInfoMemoryValueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMemValueOCT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtMemValueChar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout emuInfoPaneLayout = new javax.swing.GroupLayout(emuInfoPane);
        emuInfoPane.setLayout(emuInfoPaneLayout);
        emuInfoPaneLayout.setHorizontalGroup(
            emuInfoPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(emuInfoPaneLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(emuInfoPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(paneInfoRegisters, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
                    .addComponent(paneInfoBreak, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
                    .addComponent(paneInfoMemoryValue, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        emuInfoPaneLayout.setVerticalGroup(
            emuInfoPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(emuInfoPaneLayout.createSequentialGroup()
                .addComponent(paneInfoBreak, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(paneInfoRegisters, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addComponent(paneInfoMemoryValue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jToolBar2.setFloatable(false);
        jToolBar2.setRollover(true);
        btnReset.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/reset.gif")));
        btnReset.setText("Reset");
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });

        jToolBar2.add(btnReset);

        btnBegin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/rew.gif")));
        btnBegin.setText(bundle.getString("btnBegin")); // NOI18N
        btnBegin.setToolTipText("");
        btnBegin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBeginActionPerformed(evt);
            }
        });

        jToolBar2.add(btnBegin);

        btnBack.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/back.gif")));
        btnBack.setText(bundle.getString("btnBack")); // NOI18N
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        jToolBar2.add(btnBack);

        btnStop.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/stop.gif")));
        btnStop.setText(bundle.getString("btnStop")); // NOI18N
        btnStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStopActionPerformed(evt);
            }
        });

        jToolBar2.add(btnStop);

        btnStart.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/start.gif")));
        btnStart.setText(bundle.getString("btnStart")); // NOI18N
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        jToolBar2.add(btnStart);

        btnStep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/step.gif")));
        btnStep.setText(bundle.getString("btnStep")); // NOI18N
        btnStep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStepActionPerformed(evt);
            }
        });

        jToolBar2.add(btnStep);

        btnJump.setText(bundle.getString("btnJump")); // NOI18N
        btnJump.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJumpActionPerformed(evt);
            }
        });

        jToolBar2.add(btnJump);

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator1.setMaximumSize(new java.awt.Dimension(10, 32767));
        jSeparator1.setMinimumSize(new java.awt.Dimension(10, 0));
        jSeparator1.setPreferredSize(new java.awt.Dimension(10, 0));
        jToolBar2.add(jSeparator1);

        lblFrequency.setText(bundle.getString("txtFrequency")); // NOI18N
        jToolBar2.add(lblFrequency);

        lblFreq.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblFreq.setText("1000 kHz");
        jToolBar2.add(lblFreq);

        jSeparator10.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator10.setInheritsPopupMenu(true);
        jSeparator10.setMaximumSize(new java.awt.Dimension(15, 32768));
        jSeparator10.setMinimumSize(new java.awt.Dimension(15, 10));
        jSeparator10.setPreferredSize(new java.awt.Dimension(15, 10));
        jToolBar2.add(jSeparator10);

        lblImpulse.setText(bundle.getString("txtImpulse")); // NOI18N
        jToolBar2.add(lblImpulse);

        spnClock.setModel(new SpinnerNumberModel(1000, 1, 1000000, 100));
        spnClock.setMaximumSize(new java.awt.Dimension(80, 32767));
        spnClock.setMinimumSize(new java.awt.Dimension(80, 18));
        spnClock.setPreferredSize(new java.awt.Dimension(80, 18));
        jToolBar2.add(spnClock);

        jToolBar3.setFloatable(false);
        jLabel15.setText(bundle.getString("txtMemoryPageNumber")); // NOI18N
        jToolBar3.add(jLabel15);

        spnPage.setModel(new SpinnerNumberModel(0, 0, memModel.getPageCount()-1, 1));
        jToolBar3.add(spnPage);

        jSeparator5.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator5.setMaximumSize(new java.awt.Dimension(10, 32767));
        jSeparator5.setMinimumSize(new java.awt.Dimension(10, 0));
        jSeparator5.setPreferredSize(new java.awt.Dimension(10, 10));
        jToolBar3.add(jSeparator5);

        jLabel16.setText(bundle.getString("txtMemoryPageCount")); // NOI18N
        jToolBar3.add(jLabel16);

        lblPageCount.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblPageCount.setText(String.valueOf(cpu.mem.getSize()/256));
        lblPageCount.setText("0");
        lblPageCount.setMaximumSize(new java.awt.Dimension(20, 14));
        jToolBar3.add(lblPageCount);

        jSeparator6.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator6.setMaximumSize(new java.awt.Dimension(10, 32767));
        jSeparator6.setMinimumSize(new java.awt.Dimension(10, 10));
        jSeparator6.setPreferredSize(new java.awt.Dimension(10, 10));
        jToolBar3.add(jSeparator6);

        btnFindAddress.setText(bundle.getString("txtFindAddress")); // NOI18N
        btnFindAddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFindAddressActionPerformed(evt);
            }
        });

        jToolBar3.add(btnFindAddress);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(emuMemoryPane, javax.swing.GroupLayout.DEFAULT_SIZE, 502, Short.MAX_VALUE)
                    .addComponent(jToolBar3, javax.swing.GroupLayout.PREFERRED_SIZE, 398, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(emuDebugPane, javax.swing.GroupLayout.DEFAULT_SIZE, 502, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(emuInfoPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(jToolBar2, javax.swing.GroupLayout.DEFAULT_SIZE, 788, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jToolBar2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(emuDebugPane, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(emuMemoryPane, javax.swing.GroupLayout.DEFAULT_SIZE, 291, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jToolBar3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(emuInfoPane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        jTabbedPane1.addTab(bundle.getString("tabEmulator"), jPanel2); // NOI18N

        jTabbedPane1.getAccessibleContext().setAccessibleName("");

        jMenuFile.setText(bundle.getString("mnuFile")); // NOI18N
        jMenuItemNew.setText(bundle.getString("mnuFileNew")); // NOI18N
        jMenuItemNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemNewActionPerformed(evt);
            }
        });

        jMenuFile.add(jMenuItemNew);

        jMenuItemOpen.setText(bundle.getString("mnuFileOpen")); // NOI18N
        jMenuItemOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemOpenActionPerformed(evt);
            }
        });

        jMenuFile.add(jMenuItemOpen);

        jMenuFile.add(jSeparator8);

        jMenuItemSave.setText(bundle.getString("mnuFileSave")); // NOI18N
        jMenuItemSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemSaveActionPerformed(evt);
            }
        });

        jMenuFile.add(jMenuItemSave);

        jMenuItemSaveAs.setText(bundle.getString("mnuFileSaveAs")); // NOI18N
        jMenuItemSaveAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemSaveAsActionPerformed(evt);
            }
        });

        jMenuFile.add(jMenuItemSaveAs);

        jMenuFile.add(jSeparator7);

        jMenuItemExit.setText(bundle.getString("mnuFileExit")); // NOI18N
        jMenuItemExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemExitActionPerformed(evt);
            }
        });

        jMenuFile.add(jMenuItemExit);

        jMenuBar1.add(jMenuFile);

        jMenuEdit.setText(bundle.getString("mnuEdit")); // NOI18N
        jMenuEdit.setActionCommand("Zdrojov\u00fd k\u00f3d");
        jMenuItemCut.setText(bundle.getString("mnuEditCut")); // NOI18N
        jMenuItemCut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemCutActionPerformed(evt);
            }
        });

        jMenuEdit.add(jMenuItemCut);

        jMenuItemCopy.setText(bundle.getString("mnuEditCopy")); // NOI18N
        jMenuItemCopy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemCopyActionPerformed(evt);
            }
        });

        jMenuEdit.add(jMenuItemCopy);

        jMenuItemPaste.setText(bundle.getString("mnuEditPaste")); // NOI18N
        jMenuItemPaste.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemPasteActionPerformed(evt);
            }
        });

        jMenuEdit.add(jMenuItemPaste);

        jMenuEdit.add(jSeparator9);

        jMenuItemCompile.setText(bundle.getString("mnuEditCompile")); // NOI18N
        jMenuItemCompile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemCompileActionPerformed(evt);
            }
        });

        jMenuEdit.add(jMenuItemCompile);

        jMenuBar1.add(jMenuEdit);

        java.util.ResourceBundle bundle1 = java.util.ResourceBundle.getBundle("resources/emuResources"); // NOI18N
        jMenuLanguage.setText(bundle1.getString("mnuLanguage")); // NOI18N
        jRadioButtonMenuItemEnglish.setText(bundle.getString("mnuLanguageEnglish")); // NOI18N
        jRadioButtonMenuItemEnglish.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItemEnglishActionPerformed(evt);
            }
        });

        jMenuLanguage.add(jRadioButtonMenuItemEnglish);

        jRadioButtonMenuItemSlovak.setText(bundle.getString("mnuLanguageSlovak")); // NOI18N
        jRadioButtonMenuItemSlovak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItemSlovakActionPerformed(evt);
            }
        });

        jMenuLanguage.add(jRadioButtonMenuItemSlovak);

        jMenuBar1.add(jMenuLanguage);

        jMenuHelp.setText(bundle1.getString("mnuHelp")); // NOI18N
        jMenuItemAbout.setText(bundle.getString("mnuHelpAbout")); // NOI18N
        jMenuItemAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemAboutActionPerformed(evt);
            }
        });

        jMenuHelp.add(jMenuItemAbout);

        jMenuBar1.add(jMenuHelp);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 674, Short.MAX_VALUE)
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jRadioButtonMenuItemSlovakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItemSlovakActionPerformed
        jRadioButtonMenuItemSlovak.setSelected(true);
        jRadioButtonMenuItemEnglish.setSelected(false);
        currentLocale = new Locale("sk", "SK");
        updateLanguageStrings();
    }//GEN-LAST:event_jRadioButtonMenuItemSlovakActionPerformed

    private void jRadioButtonMenuItemEnglishActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItemEnglishActionPerformed
        jRadioButtonMenuItemSlovak.setSelected(false);
        jRadioButtonMenuItemEnglish.setSelected(true);
        currentLocale = new Locale("en", "EN");
        updateLanguageStrings();
    }//GEN-LAST:event_jRadioButtonMenuItemEnglishActionPerformed

    private void jMenuItemAboutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemAboutActionPerformed
        frmAbout f = new frmAbout(currentLocale);
        f.setVisible(true);
    }//GEN-LAST:event_jMenuItemAboutActionPerformed

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
        cpu.Reset(compiler.getProgramStart());
        this.enableEmulator();
    }//GEN-LAST:event_btnResetActionPerformed
    private void btnStopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStopActionPerformed
        cpu.stopEmul();
        this.enableEmulator();
    }//GEN-LAST:event_btnStopActionPerformed
    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
        this.disableEmulator();
        cpu.runEmul();
    }//GEN-LAST:event_btnStartActionPerformed
    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        int pc = cpu.getPC();
        if (pc > 0) cpu.setPC(pc-1);
    }//GEN-LAST:event_btnBackActionPerformed
    private void btnJumpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJumpActionPerformed
        int address = 0;
        try {
            address = Integer.decode(JOptionPane.showInputDialog(this,
                    java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgJumpAddress"),
                    java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgJumpAddressTitle"),
                    JOptionPane.QUESTION_MESSAGE,null,null,0).toString()).intValue();
        } catch(NumberFormatException e) {return;}
        catch (NullPointerException f) {return;}
        if (address <0 || address >= cpu.mem.getSize()) {
            JOptionPane.showMessageDialog(this,java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgJumpAddressError")+" "+String.valueOf(cpu.mem.getSize())+")",
                    java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgJumpAddressTitle"),JOptionPane.ERROR_MESSAGE); return;
        }
        cpu.setPC(address);
    }//GEN-LAST:event_btnJumpActionPerformed
    private void btnFindAddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFindAddressActionPerformed
        int address = 0;
        try {
            address = Integer.decode(JOptionPane.showInputDialog(this,
                    java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgFindAddress"),
                    java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgFindAddressTitle"),
                    JOptionPane.QUESTION_MESSAGE,null,null,0).toString()).intValue();
        } catch(NumberFormatException e) {return;}
        catch (NullPointerException f) {return;}
        if (address <0 || address >= cpu.mem.getSize()) {
            JOptionPane.showMessageDialog(this,java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgFindAddressError")+" "+String.valueOf(cpu.mem.getSize())+")",
                    java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgFindAddressTitle"),JOptionPane.ERROR_MESSAGE);
            return;
        }
        this.memModel.setPage(address/(memModel.getRowCount()*memModel.getColumnCount()));
    }//GEN-LAST:event_btnFindAddressActionPerformed
    private void btnStepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStepActionPerformed
        cpu.stepEmul();
    }                                           private void btnBeginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-LAST:event_btnStepActionPerformed
        cpu.setPC(compiler.getProgramStart());//GEN-FIRST:event_btnBeginActionPerformed
    }//GEN-LAST:event_btnBeginActionPerformed
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        jMenuItemCompileActionPerformed(evt);
    }//GEN-LAST:event_jButton4ActionPerformed
    private void jMenuItemCompileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemCompileActionPerformed
        boolean succ;
        jTabbedPane1.setEnabledAt(1, false);
        txtCompiler.setText("");
        succ = compiler.startCompile();
        if (succ == true) {
            txtCompiler.setText(txtCompiler.getText()+java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgCompileSuccessful"));
            jTabbedPane1.setEnabledAt(1, true);
            enableCPUListeners();
            this.memModel.setPage(compiler.getProgramStart()/(memModel.getRowCount()*memModel.getColumnCount()));
            cpu.Reset(compiler.getProgramStart());
            System.gc();
        } else {
            txtCompiler.setText(txtCompiler.getText()+java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgCompileFailed"));
        }
    }//GEN-LAST:event_jMenuItemCompileActionPerformed
    private void jMenuItemExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemExitActionPerformed
       this.processWindowEvent(new WindowEvent(this,WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_jMenuItemExitActionPerformed
    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        jMenuItemPasteActionPerformed(evt);
    }//GEN-LAST:event_jButton12ActionPerformed
    private void jMenuItemPasteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemPasteActionPerformed
        try { txtSource.paste(); }
        catch (Exception e) {}
    }//GEN-LAST:event_jMenuItemPasteActionPerformed
    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        jMenuItemCopyActionPerformed(evt);
    }//GEN-LAST:event_jButton11ActionPerformed
    private void jMenuItemCopyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemCopyActionPerformed
        try { txtSource.copy(); }
        catch (Exception e) {}
    }//GEN-LAST:event_jMenuItemCopyActionPerformed
    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        jMenuItemCutActionPerformed(evt);
    }//GEN-LAST:event_jButton10ActionPerformed
    private void jMenuItemCutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemCutActionPerformed
        try { txtSource.cut(); }
        catch (Exception e) {}
    }//GEN-LAST:event_jMenuItemCutActionPerformed
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        jMenuItemNewActionPerformed(evt);
    }//GEN-LAST:event_jButton1ActionPerformed
    private void jMenuItemNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemNewActionPerformed
        int sel;
        sel = JOptionPane.showConfirmDialog(this,
                java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgSaveConfirm"),
                java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgSaveConfirmTitle"),
                JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (sel == JOptionPane.CANCEL_OPTION) return;
        if (sel == JOptionPane.YES_OPTION) jMenuItemSaveActionPerformed(evt);
        txtSource.setText("");
        this.srcFile = null;
    }//GEN-LAST:event_jMenuItemNewActionPerformed
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        jMenuItemSaveActionPerformed(evt);
    }//GEN-LAST:event_jButton3ActionPerformed
    private void jMenuItemSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemSaveActionPerformed
        if (this.srcFile == null || srcFile.canWrite() == false) jMenuItemSaveAsActionPerformed(evt);
        else {
            String fn = srcFile.getAbsolutePath();
            try {
                FileWriter vystup = new FileWriter(fn);
                txtSource.write(vystup);
                vystup.close();
                savedFile = true;
            } 
            catch (IOException e) { System.out.println(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgSaveError")+" "+fn+" !"); }
            catch (Exception e) { System.out.println(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgUnexpectedException")); }
        }
    }//GEN-LAST:event_jMenuItemSaveActionPerformed
    private void jMenuItemSaveAsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemSaveAsActionPerformed
        JFileChooser f = new JFileChooser();
        usefulFilter f1 = new usefulFilter();
        usefulFilter f2 = new usefulFilter();
        usefulFilter f3 = new usefulFilter();

        f1.addExtension("asm");
        f1.setDescription(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgAssemblerSource"));
        f2.addExtension("txt");
        f2.setDescription(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgTextFiles"));
        f3.addExtension("*");
        f3.setDescription(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgAllFiles"));
        
        f.setDialogTitle(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgSaveDialogTitle"));
        f.setAcceptAllFileFilterUsed(false);
        f.addChoosableFileFilter(f1); f.addChoosableFileFilter(f2); f.addChoosableFileFilter(f3);
        f.setFileFilter(f1);
        f.setApproveButtonText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgSaveButton"));

        int returnVal = f.showSaveDialog(this);
        if(returnVal == JFileChooser.APPROVE_OPTION) {
            this.srcFile = f.getSelectedFile();
            if (srcFile.canWrite() == true || srcFile.exists() == false ) {
                String fn = srcFile.getAbsolutePath();
                try {
                    usefulFilter fil = (usefulFilter)f.getFileFilter();
                    if (fil.getExtension(srcFile) == null && fil.getFirstExtension()!=null) {
                        if (fil.getFirstExtension() != "*")
                            fn +="."+fil.getFirstExtension();
                    }
                    srcFile = new java.io.File(fn);
                    FileWriter vystup = new FileWriter(fn);
                    txtSource.write(vystup);
                    vystup.close();
                    savedFile = true;
                } 
                catch (IOException e) { System.out.println(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgSaveErrorException")+" "+fn+" !"); }
                catch (Exception e) { System.out.println(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgUnexpectedException")); }
            } else { System.out.println(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgSaveBadFileName")); }
        }
        f.setVisible(true);
    }//GEN-LAST:event_jMenuItemSaveAsActionPerformed
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        jMenuItemOpenActionPerformed(evt);
    }//GEN-LAST:event_jButton2ActionPerformed
    private void jMenuItemOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemOpenActionPerformed
        JFileChooser f = new JFileChooser();
        usefulFilter f1 = new usefulFilter();
        usefulFilter f2 = new usefulFilter();
        usefulFilter f3 = new usefulFilter();

        f1.addExtension("asm");
        f1.setDescription(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgAssemblerSource"));
        f2.addExtension("txt");
        f2.setDescription(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgTextFiles"));
        f3.addExtension("*");
        f3.setDescription(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgAllFiles"));
        
        f.setDialogTitle(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgOpenDialogTitle"));
        f.setAcceptAllFileFilterUsed(false);
        f.addChoosableFileFilter(f1);
        f.addChoosableFileFilter(f2);
        f.addChoosableFileFilter(f3);
        f.setFileFilter(f1);
        f.setApproveButtonText(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgOpenButton"));
        f.setSelectedFile(srcFile);

        int returnVal = f.showOpenDialog(this);
        f.setVisible(true);
        if(returnVal == JFileChooser.APPROVE_OPTION) {
            srcFile = f.getSelectedFile();
            if (srcFile.canRead() == true) {
                try {
                    FileReader vstup = new FileReader(srcFile.getAbsolutePath());
                    txtSource.setText("");
                    txtSource.getEditorKit().read(vstup, txtSource.getDocument(),0);
                    vstup.close(); savedFile = true;
                }  catch (java.io.FileNotFoundException ex) {
                    System.out.println(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgOpenError1")
                    +" "+srcFile.getPath()+" "+java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgOpenError2"));
                    return;
                }
                catch (IOException e) {
                    System.out.println(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgOpenError3"));
                }
                catch (Exception e) {
                    System.out.println(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgOpenError4"));
                }
            } else {
                System.out.println(java.util.ResourceBundle.getBundle("resources/emuResources",currentLocale).getString("msgOpenError5"));
            }
        }
    }//GEN-LAST:event_jMenuItemOpenActionPerformed
    private void emuMemoryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_emuMemoryMouseClicked
        // zmenia sa hodnoty adresy, a hodnoty v pravom paneli
        int row = emuMemory.rowAtPoint(evt.getPoint());
        int col = emuMemory.columnAtPoint(evt.getPoint());
        
        int address = memModel.getRowCount() * memModel.getColumnCount() * memModel.getPage()+ row * 16 + col;
        int value = Integer.valueOf(emuMemory.getValueAt(row,col).toString(), 16);
       
        txtAddress.setText(Integer.toHexString(address).toUpperCase()+"h");
        updateMemoryInfo(value);
    }//GEN-LAST:event_emuMemoryMouseClicked
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnBegin;
    private javax.swing.JButton btnFindAddress;
    private javax.swing.JButton btnJump;
    private javax.swing.JButton btnReset;
    private javax.swing.JButton btnStart;
    private javax.swing.JButton btnStep;
    private javax.swing.JButton btnStop;
    private javax.swing.JComboBox cmbFlagAC;
    private javax.swing.JComboBox cmbFlagC;
    private javax.swing.JComboBox cmbFlagP;
    private javax.swing.JComboBox cmbFlagS;
    private javax.swing.JComboBox cmbFlagZ;
    private javax.swing.JTable emuDebug;
    private javax.swing.JScrollPane emuDebugPane;
    private javax.swing.JPanel emuInfoPane;
    private javax.swing.JTable emuMemory;
    private javax.swing.JScrollPane emuMemoryPane;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu jMenuEdit;
    private javax.swing.JMenu jMenuFile;
    private javax.swing.JMenu jMenuHelp;
    private javax.swing.JMenuItem jMenuItemAbout;
    private javax.swing.JMenuItem jMenuItemCompile;
    private javax.swing.JMenuItem jMenuItemCopy;
    private javax.swing.JMenuItem jMenuItemCut;
    private javax.swing.JMenuItem jMenuItemExit;
    private javax.swing.JMenuItem jMenuItemNew;
    private javax.swing.JMenuItem jMenuItemOpen;
    private javax.swing.JMenuItem jMenuItemPaste;
    private javax.swing.JMenuItem jMenuItemSave;
    private javax.swing.JMenuItem jMenuItemSaveAs;
    private javax.swing.JMenu jMenuLanguage;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItemEnglish;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItemSlovak;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JToolBar jToolBar2;
    private javax.swing.JToolBar jToolBar3;
    private javax.swing.JLabel lblDuration;
    private javax.swing.JLabel lblFlag0;
    private javax.swing.JLabel lblFlag1;
    private javax.swing.JLabel lblFlag2;
    private javax.swing.JLabel lblFlag3;
    private javax.swing.JLabel lblFlag4;
    private javax.swing.JLabel lblFreq;
    private javax.swing.JLabel lblFrequency;
    private javax.swing.JLabel lblImpulse;
    private javax.swing.JLabel lblPSW;
    private javax.swing.JLabel lblPageCount;
    private javax.swing.JLabel lblProcessor;
    private javax.swing.JLabel lblReasonStopped;
    private javax.swing.JLabel lblReg0;
    private javax.swing.JLabel lblReg1;
    private javax.swing.JLabel lblReg2;
    private javax.swing.JLabel lblReg3;
    private javax.swing.JLabel lblReg4;
    private javax.swing.JLabel lblReg5;
    private javax.swing.JLabel lblReg6;
    private javax.swing.JLabel lblStates;
    private javax.swing.JLabel lblTheoretical;
    private javax.swing.JPanel paneInfoBreak;
    private javax.swing.JPanel paneInfoMemoryValue;
    private javax.swing.JPanel paneInfoRegisters;
    private javax.swing.JSpinner spnClock;
    private javax.swing.JSpinner spnPage;
    private javax.swing.JTextField txtAddress;
    private javax.swing.JTextArea txtCompiler;
    private javax.swing.JTextField txtFR;
    private javax.swing.JTextField txtMemValueBIN;
    private javax.swing.JTextField txtMemValueChar;
    private javax.swing.JTextField txtMemValueDEC;
    private javax.swing.JTextField txtMemValueHEX;
    private javax.swing.JTextField txtMemValueOCT;
    private javax.swing.JTextField txtRegA;
    private javax.swing.JTextField txtRegB;
    private javax.swing.JTextField txtRegBC;
    private javax.swing.JTextField txtRegC;
    private javax.swing.JTextField txtRegD;
    private javax.swing.JTextField txtRegDE;
    private javax.swing.JTextField txtRegE;
    private javax.swing.JTextField txtRegH;
    private javax.swing.JTextField txtRegHL;
    private javax.swing.JTextField txtRegL;
    private javax.swing.JTextField txtRegSP;
    private javax.swing.JTextPane txtSource;
    // End of variables declaration//GEN-END:variables
}
