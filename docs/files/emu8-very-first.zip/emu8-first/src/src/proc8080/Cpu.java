/*
 * Cpu.java
 *
 * Created on Utorok, 2007, marec 6, 21:42
 *
 * KEEP IT SIMPLY STUPID
 */

package proc8080;

import devices.*;
import java.util.*;
import java.lang.*;
    
/**
 * Trieda procesora - musi byt maximalne kompatibilna pre vsetky ostatne procesory
 * @author vbmacher
 */
public class Cpu implements Runnable {
    /* vnutorna struktura emulatora */
    public Memory mem; // operacna pamat
    
    private int PC, SP;
    private short B, C, D, E, H, L, FR, A; // registre

    public final int flagS = 0x80, flagZ = 0x40, flagAC = 0x10, flagP = 0x4, flagC = 0x1;
    public final int regPC = 0x1, regSP = 0x2, regB = 0x4, regC = 0x8, regD = 0x10, regE = 0x20,
                     regH = 0x40, regL = 0x80, regA = 0x100, regM = 0x200, regPSW = 0x400;
    public final int stoppedChanged = 0x800;

    private boolean[] parityTable = {true,false,false,true,false,true,true,false,false,true,true,false,true,false,false,true,false,true,true,false,true,false,false,true,true,false,false,true,false,true,true,false,false,true,true,false,true,false,false,true,true,false,false,true,false,true,true,false,true,false,false,true,false,true,true,false,false,true,true,false,true,false,false,true,false,true,true,false,true,false,false,true,true,false,false,true,false,true,true,false,true,false,false,true,false,true,true,false,false,true,true,false,true,false,false,true,true,false,false,true,false,true,true,false,false,true,true,false,true,false,false,true,false,true,true,false,true,false,false,true,true,false,false,true,false,true,true,false,false,true,true,false,true,false,false,true,true,false,false,true,false,true,true,false,true,false,false,true,false,true,true,false,false,true,true,false,true,false,false,true,true,false,false,true,false,true,true,false,false,true,true,false,true,false,false,true,false,true,true,false,true,false,false,true,true,false,false,true,false,true,true,false,true,false,false,true,false,true,true,false,false,true,true,false,true,false,false,true,false,true,true,false,true,false,false,true,true,false,false,true,false,true,true,false,false,true,true,false,true,false,false,true,true,false,false,true,false,true,true,false,true,false,false,true,false,true,true,false,false,true,true,false,true,false,false,true };
    private boolean[] signTable = {false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true };
    private short[] dcrTable = {150,70,2,2,6,2,6,6,2,2,6,6,2,6,2,2,22,2,6,6,2,6,2,2,6,6,2,2,6,2,6,6,18,2,6,6,2,6,2,2,6,6,2,2,6,2,6,6,18,6,2,2,6,2,6,6,2,2,6,6,2,6,2,2,22,2,6,6,2,6,2,2,6,6,2,2,6,2,6,6,18,6,2,2,6,2,6,6,2,2,6,6,2,6,2,2,22,6,2,2,6,2,6,6,2,2,6,6,2,6,2,2,22,2,6,6,2,6,2,2,6,6,2,2,6,2,6,6,18,130,134,134,130,134,130,130,134,134,130,130,134,130,134,134,146,134,130,130,134,130,134,134,130,130,134,134,130,134,130,130,150,134,130,130,134,130,134,134,130,130,134,134,130,134,130,130,150,130,134,134,130,134,130,130,134,134,130,130,134,130,134,134,146,134,130,130,134,130,134,134,130,130,134,134,130,134,130,130,150,130,134,134,130,134,130,130,134,134,130,130,134,130,134,134,146,130,134,134,130,134,130,130,134,134,130,130,134,130,134,134,146,134,130,130,134,130,134,134,130,130,134,134,130,134,130,130};
    private short[] inrTable = {2,2,6,2,6,6,2,2,6,6,2,6,2,2,6,18,6,6,2,6,2,2,6,6,2,2,6,2,6,6,2,18,6,6,2,6,2,2,6,6,2,2,6,2,6,6,2,22,2,2,6,2,6,6,2,2,6,6,2,6,2,2,6,18,6,6,2,6,2,2,6,6,2,2,6,2,6,6,2,22,2,2,6,2,6,6,2,2,6,6,2,6,2,2,6,22,2,2,6,2,6,6,2,2,6,6,2,6,2,2,6,18,6,6,2,6,2,2,6,6,2,2,6,2,6,6,2,146,134,134,130,134,130,130,134,134,130,130,134,130,134,134,130,150,130,130,134,130,134,134,130,130,134,134,130,134,130,130,134,150,130,130,134,130,134,134,130,130,134,134,130,134,130,130,134,146,134,134,130,134,130,130,134,134,130,130,134,130,134,134,130,150,130,130,134,130,134,134,130,130,134,134,130,134,130,130,134,146,134,134,130,134,130,130,134,134,130,130,134,130,134,134,130,146,134,134,130,134,130,130,134,134,130,130,134,130,134,134,130,150,130,130,134,130,134,134,130,130,134,134,130,134,130,130,134,86};
    
    /* beh emulatora */
    private int clockFrequency; // v [kHz] = [ms^-1]
    private int clockPeriode; // v [ns]
    private final int sliceLength = 1; // casove doladenie velkosti useku prudu instrukcii [ms]
    private long endTime = 0, startTimeSaved=0; // merane casy pri behu emulatora
    private int tStatesExecuted = 0; // pocet vykonanych operacnych krokov (po ukonceni runEmul)
    private Thread cpuThread;
    public enum rsnEnum { reasonNormal, reasonBreakpoint, reasonBadAddress , reasonBadInstruction }
    private boolean INTE; // povolenie / zakazanie preruseni
    private boolean running; // ci bezi emulator
    private rsnEnum reasonStopped; // dovod zastavenia emulatora
    private HashSet breaks;

    /* listeners zmeny */
    protected javax.swing.event.EventListenerList listenerList = new javax.swing.event.EventListenerList();
    private cpuChangeStateEvent chev;
    private int regChanged; // pred kazdou instrukciou sa vynuluje
    
    /**
     * zatial bez zariadeni, 64kB pamat
     */
    public Cpu() {
        mem = new Memory(65536);
        clockFrequency = 1000; // 1 MHz
        clockPeriode = 1000; // 1 ms
        INTE = false; // najprv su prerusenia zakazane
        running = false;
        reasonStopped = rsnEnum.reasonNormal;
        chev = new cpuChangeStateEvent(this);
        breaks = new HashSet();
    }
    
    // nastavi frekvenciu procesora, parameter: perioda hodinovych impulzov
    // 1 kHz = 1000/s = 1000/(1000 ms) = ms^(-1)
    public void setCPUClock(int nanos) {
        if (nanos <= 0) return;
        clockPeriode = nanos;
        float x;
        x = (float)nanos;
        x /= 1000000; // prevod nanosekund na milisekundy
        if (x == 0.0) x = (float)1.0;
        clockFrequency = (int)(1 / x);
    }
    
    public int getCPUClock() { return clockPeriode; }
    public int getCPUFreq() { return clockFrequency; }
    
    public short getFR() { return this.FR; }
    public short getRegB() { return this.B; }
    public short getRegC() { return this.C; }
    public short getRegD() { return this.D; }
    public short getRegE() { return this.E; }
    public short getRegH() { return this.H; }
    public short getRegL() { return this.L; }
    public short getRegA() { return this.A; }
    public int getRegSP() { return this.SP; }
    public void setRegB(short val) { B = val; fireCpuChangeStateEvent(chev, regB);}
    public void setRegC(short val) { C = val; fireCpuChangeStateEvent(chev, regC);}
    public void setRegD(short val) { D = val; fireCpuChangeStateEvent(chev, regD);}
    public void setRegE(short val) { E = val; fireCpuChangeStateEvent(chev, regE);}
    public void setRegH(short val) { H = val; fireCpuChangeStateEvent(chev, regH);}
    public void setRegL(short val) { L = val; fireCpuChangeStateEvent(chev, regL);}
    public void setRegA(short val) { A = val; fireCpuChangeStateEvent(chev, regA);}
    public void setRegSP(int val) { SP = val; fireCpuChangeStateEvent(chev, regSP);}
    public int getPC() { return (this.PC & 0xFFFF); }
    public void setPC(int new_value) { this.PC = (new_value & 0xFFFF); fireCpuChangeStateEvent(chev, regPC); }
    
    // priznaky
    public boolean getFlag(int flag) { if ((FR & flag) == 0) return false; else return true; }
    public void setFlag(int flag, boolean value) { if (value) FR |= flag; else FR &= (~flag); regChanged |= regPSW; }
    
    
    /********************* emulacia **********************/
    
    public void Reset(int programStart) {
      //  mem.clearMemory();
        // vynulovanie registrov
        SP = A = B = C = D = E = H = L = 0;
        // reset priznakov
        FR = 0x42; //0100 0010b
        PC = programStart;
        INTE = false;
        running = false;
        reasonStopped = rsnEnum.reasonBreakpoint;
        cpuThread = null;
        fireCpuChangeStateEvent(chev, regA | regB | regC | regD | regE | regH | regL | regPC | regSP | regPSW | stoppedChanged);
    }
    
    public void setBreakpoint(int address) { breaks.add(address); }
    public boolean isBreakpoint(int address) { return breaks.contains(address); }
    public void clearBreakpoint(int address) { breaks.remove(address); }
    
    /* implementacia vlakna - spustenie emulacie */
    /*
     * poznamka k realtime simulaciam:
     *
     * kazda instrukcia sa vykona za niekolko op. krokov, pricom kazdy op. krok je definovany
     * periodou hodinovych impulzov
     *
     * takze najjednoduchsie riesenie real-time je:
     * startTime = microSecondsTime();
     * while (running) {
     *   tStates = instruction();
     *   endTime = microSecondsTime();
     *   startTime += (tStates * tStateMicroSecondsPeriode);
     *   if (startTime > endTime) {
     *     waitMicroSeconds(startTime - endTime);
     *   }
     * }
     * 
     * kedze v jave existuju funkcie na cakanie s presnostou na 10 ms a na meranie casu
     * s presnostou 1 ns, musim ratat s presnostou 10ms a preto sa oplati uvedeny pristup
     * pouzit iba v pripade, ak tStates > 10. Priemerne je tStates = 7.5 a preto musim "pustit"
     * minimalne 2 instrukcie bez kontroly, aby bola kontrola presnejsia.
     * Riesenie bude:
     *
     * tStatesInSlice = 15;
     * startTime = microSecondsTime();
     * while (running) {
     *   tStates += instruction();
     *   if (tStates >= tStatesInSlice) {
     *     endTime = microSecondsTime();
     *     startTime += (tStatesInSlice * tStateMicroSecondsPeriode);
     *     tStates -= tStatesInSlice;
     *     if (startTime > endTime) waitMicroSeconds(startTime - endTime);
     *   }
     * }
     *
     * Iny pristup (pouzity) je zalozeny na tom, ze hodinova frekvencia udava pocet
     * vykonanych operacnych krokov za casovu jednotku. Pre kHz by to bol pocet krokov
     * za 1 ms. Z toho sa potom odvadza aj tStatesInSlice, ktoreho definicia bude teraz
     * zasahovat az v dvoch rozmeroch - 1. pocet krokov za casovu jednotku
     * 2. teoreticke zvysenie systemoveho casu o casovu jednotku, ak sa vykonalo tolko krokov
     *
     *   tStatesInSlice = clockFrequency * sliceLength; 
     *
     * kde sliceLength je casove doladenie presnosti (ma hodnotu 1).
     *
     * Potom:
     *   startTime = nanoSecondsTime();
     *   while (running) {
     *     tStates += instruction();
     *     if (tStates >= tStatesInSlice) {
     *        startTime += 1000000;
     *        tStates -= tStatesInSlice;
     *        endTime = nanoSecondsTime();
     *        if (startTime > endTime) {
     *          waitNanoSeconds(startTime - endTime);
     *        }
     *     }
     *   }
     *
     * tStatesInSlice by mala byt > aspon ako priemerny pocet operacnych krokov 1 instrukcie (co je 7.55)
     *
     */
    public void run() {
      long startTime = 0;
      int tStates = 0;
      int tStatesInSlice;
      int tS; // pocet krokov 1 instrukcie
      
      tStatesInSlice = sliceLength * clockFrequency; // 1000 kHz = 1000 instrukcii bez kontroly
      tStatesExecuted = 0;
      startTimeSaved = startTime = System.nanoTime();
      if ((running == false) && (reasonStopped == rsnEnum.reasonBreakpoint)) { running = true; reasonStopped = rsnEnum.reasonNormal; }
      fireCpuChangeStateEvent(chev, regA | regB | regC | regD | regE | regH | regL | regPC | regSP | regPSW | regM | stoppedChanged);
      while(running) {
         regChanged = 0;
         tS = evalStep();
         tStatesExecuted += tS;
         tStates += tS;
         if (tStates >= tStatesInSlice) {
             /*
              * tu je ta sila presnosti:
              * frekvencia original v Hz znamena tolko oper. krokov za 1 sekundu
              * to znamena za 1 ms bude v kHz
              *
              * tStatesInSlice vyjadruje kolko oper. krokov za casovu jednotku sa ma vykonat
              * cize teoreticky by sa mal cas po ich vykonani zvacsit o tuto casovu jednotku
              * a prakticky sa to odmeria a porovna sa vysledok s teoretickym. ak je teoreticky
              * vacsi, caka sa rozdiel casov.
              *
              */
             //startTime += (tStatesInSlice*1000); // povodna verzia, chyba
             startTime += 1000000; // 1 ms
             tStates -= tStatesInSlice;
             endTime = System.nanoTime();
             if (startTime > endTime) {
                 fireCpuChangeStateEvent(chev, regPC);
                 try { cpuThread.sleep((startTime - endTime)/1000000); }
                 catch(java.lang.InterruptedException e) {}
             }
         }
         cpuThread.yield();
         if (breaks.contains(PC) == true) { running = false; reasonStopped = rsnEnum.reasonBreakpoint; }
      }
      endTime = System.nanoTime();
      fireCpuChangeStateEvent(chev, regA | regB | regC | regD | regE | regH | regL | regPC | regSP | regPSW | regM | stoppedChanged);
    }
    
    // metoda sa ma volat az po ukonceni cinnosti emulatora (runEmul)
    // vracia skutocne trvanie programu v ms
    public float getTrueDuration() {
        return (endTime-startTimeSaved)/1000000;
    }
    
    // metoda sa ma volat az po ukonceni cinnosti emulatora (runEmul)
    // vracia teoreticke trvanie programu v ms (ako dlho by mal bezat s danou frekvenciou CPU)
    public float getTheoreticalDuration() {
        return (float)((float)clockPeriode/1000000.0)*(float)tStatesExecuted;
    }
    
    public int getStatesExecuted() {
        return tStatesExecuted;
    }
    // vykona program az do zastavenia (hlt) alebo do pretecenia PC
    public void runEmul() {
        cpuThread = new Thread(this, "i8080");
        cpuThread.start();
    }
    
    // zastavi emulaciu
    public void stopEmul() {
        running = false;
        reasonStopped = rsnEnum.reasonBreakpoint;
    }
    
    // vykona 1 krok - bez merania casov (bez real-time odozvy)
    public boolean stepEmul() {
        if (running == false && (reasonStopped == rsnEnum.reasonBreakpoint)) {
            running = true; reasonStopped = rsnEnum.reasonNormal;
        }
        tStatesExecuted = 0;
        startTimeSaved = System.nanoTime();
        if (running == true) tStatesExecuted = evalStep();
        endTime = System.nanoTime();
        if (running == true) {  running = false; reasonStopped = rsnEnum.reasonBreakpoint; }
        fireCpuChangeStateEvent(chev, regChanged | stoppedChanged);
        return false;
    }
    
    public rsnEnum getReasonStopped() {
        return reasonStopped;
    }
    
    /* nastavi priznaky a scita 3 cisla, 1. cislo je hodnota registra A, vysledok do A */
    private void add3vals(short val2, short val3) {
        if ((A >> 4)  != ((A+val2+val3) >> 4)) setFlag(flagAC, true); else setFlag(flagAC, false);
        if ((A+val2+val3) > ((A+val2+val3)&0xFF)) setFlag(flagC,true); else setFlag(flagC,false);
        A = (short)((A + val2 + val3)&0xFF);
        setFlag(flagZ, (A == 0)); setFlag(flagS,signTable[A & 0xFF]); setFlag(flagP,parityTable[A & 0xFF]);        
    }

    /* nastavi priznaky odcitanim 3 cisel, 1. cislo je hodnota registra A, vracia vysledok
     * pouziva sa pre sub3vals, cmp
     */
    private short subFlags(short val2, short val3) {
        short v;
        if ((A >> 4)  != ((A-val2-val3) >> 4)) setFlag(flagAC, true); else setFlag(flagAC, false);
        if ((A-val2-val3) > ((A-val2-val3)&0xFF)) setFlag(flagC,true); else setFlag(flagC,false);
        v = (short)((A - val2 - val3)&0xFF);
        setFlag(flagZ, (v == 0)); setFlag(flagS,signTable[v & 0xFF]); setFlag(flagP,parityTable[v & 0xFF]);
        return v;
    }
    
    /* nastavi priznaky a odcita 3 cisla, 1. cislo je hodnota registra A, vysledok do A */
    private void sub3vals(short val2, short val3) {
        A = subFlags(val2, val3);
    }
    
    private short getRegVal(byte regType) {
        switch (regType) {
            case 0: return B; case 1: return C; case 2: return D; case 3: return E; case 4: return H; case 5: return L;
            case 6: return mem.getCell((int)((H << 8) | L)); case 7: return A;
        }
        return (short)0;
    }

    private void setRegVal(byte regType, short val) {
        switch (regType) {
            case 0: B = val; regChanged |= regB; break; case 1: C = val; regChanged |= regC; break;
            case 2: D = val; regChanged |= regD; break; case 3: E = val; regChanged |= regE; break;
            case 4: H = val; regChanged |= regH; break; case 5: L = val; regChanged |= regL; break;
            case 6: mem.setCell((int)((H << 8) | L), val); regChanged |= regM; break;
            case 7: A = val; regChanged |= regA; break;
        }
    }

    private int getRPVal(byte rpType, boolean mustSP) {
        switch (rpType) {
            case 0: return (int)((B << 8) | C); case 1: return (int)((D << 8) | E);
            case 2: return (int)((H << 8) | L); case 3: if (mustSP == true) return SP; else return (int)((A << 8) | FR);
        }
        return 0;
    }

    private void setRPVal(byte rpType, int val, boolean mustSP) {
        short high, low;
        high = (short)((val >>> 8) & 0xFF); low = (short)(val & 0xFF);
        switch (rpType) {
            case 0: B = high; C = low; regChanged |= (regB | regC); break; case 1: D = high; E = low; regChanged |= (regD | regE); break;
            case 2: H = high; L = low; regChanged |= (regH | regL); break; 
            case 3: if (mustSP == true) { SP = (int)((high << 8) | low); regChanged |= regSP; } else { A = high; FR = low; FR |= 0x42; regChanged |= (regA | regPSW); }
        }
    }    

    private void setRPVal(byte rpType, short low, short high, boolean mustSP) {
        switch (rpType) {
            case 0: B = high; C = low; regChanged |= (regB | regC); break; case 1: D = high; E = low; regChanged |= (regD | regE); break;
            case 2: H = high; L = low; regChanged |= (regH | regL); break;
            case 3: if (mustSP == true) { SP = (int)((high << 8) | low); regChanged |= regSP;} else { A = high; FR = low; FR |= 0x42; regChanged |= (regA | regPSW); }
        }
    }    
    
    // vrati true ak je splnena podmienka podmieneneho skoku
    private boolean getCondFlag(byte flagType) {
        switch (flagType) {
            case 0: return (getFlag(flagZ) == false); case 1: return (getFlag(flagZ) == true);
            case 2: return (getFlag(flagC) == false); case 3: return (getFlag(flagC) == true);
            case 4: return (getFlag(flagP) == false); case 5: return (getFlag(flagP) == true);
            case 6: return (getFlag(flagS) == false); case 7: return (getFlag(flagS) == true);
        }
        return false;
    }
    
    /* urobi emulaciu 1 instrukcie */
    private int evalStep() {
        short instr, val,tmp,high,low;
        byte op1,op2;
        int addr;
        int tState = 0;
        boolean definite = true;
        
        instr = mem.getCell(PC++);
        switch (instr) {
/*lda add*/ case 58: try { addr = mem.getCellWord(PC); setRegVal((byte)7,mem.getCell(addr));} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} finally {tState = 13;PC+=2;} break;
/*sta add*/ case 50: try { addr = mem.getCellWord(PC); mem.setCell(addr, A); regChanged |= regM;} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} finally {tState = 13;PC+=2;} break;
/*lhld ad*/ case 42: try { addr = mem.getCellWord(PC); setRegVal((byte)5,mem.getCell(addr)); setRegVal((byte)4,mem.getCell(addr+1));} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} finally {PC+=2; tState = 16;} break;
/*shld ad*/ case 34: try { addr = mem.getCellWord(PC); mem.setCell(addr, L); mem.setCell(addr+1, H);regChanged |= regM;} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} finally {PC+=2; tState = 16;} break;
/*xchg */   case 235: val = H; setRegVal((byte)4,D); setRegVal((byte)2,val); val = L; setRegVal((byte)5, E); setRegVal((byte)3,val); tState = 4; break;
/*sphl*/    case 249: setRPVal((byte)3,L,H,true); tState = 5; break;
/*xthl*/    case 227: tState = 18; try { val = mem.getCell(SP); mem.setCell(SP, L); setRegVal((byte)5, val); val = mem.getCell(SP+1); mem.setCell(SP+1, H); setRegVal((byte)4, val);regChanged |= regM; } catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress; } break;
/*in por*/  case 219: tState = 10; break;
/*out por*/ case 211: tState = 10; break;
/*adi byt*/ case 198: try {add3vals(mem.getCell(PC),(short)0);} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress; } finally {PC+=1;tState = 7;} break;
/*aci byt*/ case 206: try { add3vals(mem.getCell(PC),(getFlag(flagC) == true) ? (short)1 : (short)0);} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress; } finally {PC+=1; tState = 7;} break;
/*sui byt*/ case 214: try { sub3vals(mem.getCell(PC),(short)0);} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} finally {PC+=1; tState = 7;} break;
/*sbi byt*/ case 222: try { sub3vals(mem.getCell(PC),(getFlag(flagC) == true) ? (short)1 : (short)0);} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} finally {PC+=1;tState = 7;} break;
/*cpi byt*/ case 254: try { subFlags(mem.getCell(PC),(short)0);} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} finally {PC+=1;tState = 7;} break;
/*daa */    case 39: if ((A & 15) > 9 || getFlag(flagAC) == true) add3vals((short)0x6,(short)0); if ((A & 240) > 9 || getFlag(flagC) == true) add3vals((short)0x60,(short)0); tState = 4; break;
/*ani byt*/ case 230: try { setRegVal((byte)7, (short)((A & mem.getCell(PC))&0xFF)); if (A == 0) setFlag(flagZ, true); else setFlag(flagZ, false); setFlag(flagAC, false); setFlag(flagC, false); setFlag(flagS,signTable[A & 0xFF]); setFlag(flagP,parityTable[A & 0xFF]);} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} finally {PC+=1;tState = 7;} break;
/*ori byt*/ case 246: try { setRegVal((byte)7, (short)((A | mem.getCell(PC))&0xFF)); if (A == 0) setFlag(flagZ, true); else setFlag(flagZ, false); setFlag(flagAC, false); setFlag(flagC, false); setFlag(flagS,signTable[A & 0xFF]); setFlag(flagP,parityTable[A & 0xFF]);} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} finally {PC+=1;tState = 7;} break;
/*xri byt*/ case 238: try { setRegVal((byte)7, (short)((A ^ mem.getCell(PC))&0xFF)); if (A == 0) setFlag(flagZ, true); else setFlag(flagZ, false); setFlag(flagAC, false); setFlag(flagC, false); setFlag(flagS,signTable[A & 0xFF]); setFlag(flagP,parityTable[A & 0xFF]);} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} finally {PC+=1;tState = 7;} break;
/*cma */    case 47: setRegVal((byte)7, (short)(~A)); tState = 4; break;
/*rlc */    case 7:  val = (short)(A & 128); A <<= 1; A |= val; regChanged |= regA; if (val != 0) setFlag(flagC, true); else setFlag(flagC, false); tState = 4; break;
/*rrc */    case 15: val = (short)((A & 1)<<7); A >>>= 1; A|= val; regChanged |= regA; if (val != 0) setFlag(flagC, true); else setFlag(flagC, false); tState = 4; break;
/*ral */    case 23: val = (short)(A & 128); A <<= 1; if (getFlag(flagC) == true) A |= 1; if (val != 0) setFlag(flagC, true); else setFlag(flagC, false); tState = 4; break;
/*rar */    case 31: val = (short)(A & 1); A >>>= 1; if (getFlag(flagC) == true) A |= 128; if (val != 0) setFlag(flagC, true); else setFlag(flagC, false); tState = 4; break;
/*stc*/     case 55: setFlag(flagC, true); tState = 4; break;
/*cmc*/     case 63: setFlag(flagC, !getFlag(flagC)); tState = 4; break;
/*pchl*/    case 233: PC = (int)((H << 8) | L); tState = 5; break;
/*jmp add*/ case 195: tState = 10; try { addr = mem.getCellWord(PC); PC = (addr & 0xFFFF); } catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} break;
/*call add*/case 205: tState = 17; try { addr = mem.getCellWord(PC); high = (short)(((PC+2) >>> 8) & 0xFF); low = (short)((PC+2) & 0xFF); mem.setCell(SP-1, high); mem.setCell(SP-2, low); setRPVal((byte)3, SP-2, true); PC = (addr & 0xFFFF); regChanged |= regM;} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} break;
/*ret*/     case 201: tState = 10; try { low = mem.getCell(SP); high = mem.getCell(SP+1); PC = ((int)((high << 8) | low) & 0xFFFF); setRPVal((byte)3, SP + 2, true); } catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} break;
/*ei*/      case 251: INTE = true; tState = 4; break;
/*di*/      case 243: INTE = false; tState = 4; break;
/*hlt*/     case 118: running = false; reasonStopped = rsnEnum.reasonNormal; tState = 7; break;
/*nop*/     case 0: tState = 4; break;
/*mov r,r*/ case 64: case 65: case 66: case 67: case 68: case 69: case 70: case 71: case 72: case 73: case 74: case 75: case 76: case 77:
            case 78: case 79: case 80: case 81: case 82: case 83: case 84: case 85: case 86: case 87: case 88: case 89: case 90: case 91:
            case 92: case 93: case 94: case 95: case 96: case 97: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105:
            case 106: case 107: case 108: case 109: case 110: case 111: case 112: case 113: case 114: case 115: case 116: case 117: case 119:
            case 120: case 121: case 122: case 123: case 124: case 125: case 126: case 127: op1 = (byte)((instr & 56)>>>3); op2 = (byte)(instr & 7); tState = 5; if (op1 == 6 || op2 == 6) tState = 7; try { setRegVal(op1, getRegVal(op2)); } catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress; } break;
/*dcr r*/   case 5: case 13: case 21: case 29: case 37: case 45: case 53: case 61: op1 = (byte)((instr & 56)>>>3); tState = 5; if (op1 == 6) tState = 10; try {
    tmp = getRegVal(op1);
    FR |= dcrTable[tmp]; FR &= (dcrTable[tmp] | 1);
    regChanged |= regPSW;
    setRegVal(op1,(short)((tmp-1)&0xFF));} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} break;
/*ldax rp*/ case 10: case 26: op1 = (byte)((instr & 48)>>>4); if (op1 <= 1) { tState = 7; addr = getRPVal(op1,true); try { setRegVal((byte)7, mem.getCell(addr));} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} } else {definite = false;} break;
/*stax rp*/ case 2: case 18: op1 = (byte)((instr & 48)>>>4); if (op1 <= 1) { tState = 7; addr = getRPVal(op1,true); try { mem.setCell(addr, A);regChanged |= regM;} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} } else { definite = false; } break;
/*mvi r,by*/case 6: case 14: case 22: case 30: case 38: case 46: case 54: case 62: op1 = (byte)((instr & 56)>>>3); tState = 7; if (op1 == 6) tState = 10;  try { setRegVal(op1, mem.getCell(PC)); } catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress; } finally {PC+=1;} break;
/*lxi rp,d*/case 1: case 17: case 33: case 49: op1 = (byte)((instr & 48)>>>4); tState = 10; try { setRPVal(op1, mem.getCell(PC), mem.getCell(PC+1), true); } catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress; } finally {PC+=2;} break;
/*pop rp*/  case 193: case 209: case 225: case 241: op1 = (byte)((instr & 48)>>>4); tState = 10; try { setRPVal(op1, mem.getCell(SP), mem.getCell(SP+1), false); setRPVal((byte)3,SP+2,true);} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress; } break;
/*push rp*/ case 197: case 213: case 229: case 245: op1 = (byte)((instr & 48)>>>4); tState = 11; high = (short)((getRPVal(op1,false) >>> 8) & 0xFF); low = (short)(getRPVal(op1,false) & 0xFF); try { mem.setCell(SP-1, high); mem.setCell(SP-2, low); setRPVal((byte)3,SP-2,true);regChanged |= regM;} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress; } break;
/*add r*/   case 128: case 129: case 130: case 131: case 132: case 133: case 134: case 135: op1 = (byte)(instr & 7); tState = 4; if (op1 == 6) tState = 7; try { add3vals(getRegVal(op1),(short)0); } catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress; } break;
/*adc r*/   case 136: case 137: case 138: case 139: case 140: case 141: case 142: case 143: op1 = (byte)(instr & 7); tState = 4; if (op1 == 6) tState = 7; try { add3vals(getRegVal(op1),(getFlag(flagC) == true) ? (short)1 : (short)0); } catch (IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress; } break;
/*dad rp*/  case 9: case 25: case 41: case 57: op1 = (byte)((instr & 48)>>>4); tState = 10; high = (short)((getRPVal(op1,true) >>> 8) & 0xFF); low = (short)(getRPVal(op1,true) & 0xFF); if ((H+high) > ((H+high)&0xFF)) setFlag(flagC,true); else setFlag(flagC,false); if ((L+low) > ((L+low)&0xFF)) setFlag(flagC,true); setRegVal((byte)4,(short)((H + high)&0xFF)); setRegVal((byte)5,(short)((L + low)&0xFF)); break;
/*sub r*/   case 144: case 145: case 146: case 147: case 148: case 149: case 150: case 151: op1 = (byte)(instr & 7); tState = 4; if (op1 == 6) tState = 7; try { sub3vals(getRegVal(op1),(short)0);} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} break;
/*sbb r*/   case 152: case 153: case 154: case 155: case 156: case 157: case 158: case 159: op1 = (byte)(instr & 7); tState = 4; if (op1 == 6) tState = 7; try { sub3vals(getRegVal(op1), (getFlag(flagC) == true) ? (short)1 : (short)0);} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} break;
/*inr r*/   case 4: case 12: case 20: case 28: case 36: case 44: case 52: case 60: op1 = (byte)((instr & 56)>>>3); tState = 5; if (op1 == 6) tState = 10; try { tmp = getRegVal(op1); FR |= inrTable[tmp]; FR &= (inrTable[tmp] | 1); regChanged |= regPSW; setRegVal(op1,(short)((tmp+1)&0xFF));} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} break;
/*inx rp*/  case 3: case 19: case 35: case 51: op1 = (byte)((instr & 48)>>>4); tState = 5; addr = getRPVal(op1, true) + 1; setRPVal(op1, (short)(addr & 0xFF),(short)((addr >>> 8) & 0xFF), true); break;
/*dcx rp*/  case 11: case 27: case 43: case 59: op1 = (byte)((instr & 48)>>>4); tState = 5; addr = getRPVal(op1, true) - 1; setRPVal(op1, (short)(addr & 0xFF),(short)((addr >>> 8) & 0xFF), true); break;
/*cmp r*/   case 184: case 185: case 186: case 187: case 188: case 189: case 190: case 191: op1 = (byte)(instr & 7); tState = 4; if (op1 == 6) tState = 7; try { subFlags(getRegVal(op1),(short)0);} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} break;
/*ana r*/   case 160: case 161: case 162: case 163: case 164: case 165: case 166: case 167: op1 = (byte)(instr & 7); tState = 4; if (op1 == 6) tState = 7; try { setRegVal((byte)7,(short)((A & getRegVal(op1))&0xFF)); if (A == 0) setFlag(flagZ, true); else setFlag(flagZ, false); setFlag(flagAC, false); setFlag(flagC, false); setFlag(flagS,signTable[A & 0xFF]); setFlag(flagP,parityTable[A & 0xFF]);} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} break;
/*ora r*/   case 176: case 177: case 178: case 179: case 180: case 181: case 182: case 183: op1 = (byte)(instr & 7); tState = 4; if (op1 == 6) tState = 7; try { setRegVal((byte)7,(short)((A | getRegVal(op1))&0xFF)); if (A == 0) setFlag(flagZ, true); else setFlag(flagZ, false); setFlag(flagAC, false); setFlag(flagC, false); setFlag(flagS,signTable[A & 0xFF]); setFlag(flagP,parityTable[A & 0xFF]);} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} break;
/*xra r*/   case 168: case 169: case 170: case 171: case 172: case 173: case 174: case 175: op1 = (byte)(instr & 7); tState = 4; if (op1 == 6) tState = 7; try { setRegVal((byte)7,(short)((A ^ getRegVal(op1))&0xFF)); if (A == 0) setFlag(flagZ, true); else setFlag(flagZ, false); setFlag(flagAC, false); setFlag(flagC, false); setFlag(flagS,signTable[A & 0xFF]); setFlag(flagP,parityTable[A & 0xFF]);} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} break;
/*jX add*/  case 194: case 202: case 210: case 218: case 226: case 234: case 242: case 250: op1 = (byte)((instr & 56)>>>3); tState = 10; try { addr = mem.getCellWord(PC); if (getCondFlag(op1) == true) PC = addr-2; } catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} finally {PC+=2;} break;
/*cX add*/  case 196: case 204: case 212: case 220: case 228: case 236: case 244: case 252: op1 = (byte)((instr & 56)>>>3); tState = 11; try { addr = mem.getCellWord(PC); high = (short)(((PC+2) >>> 8) & 0xFF); low = (short)((PC+2) & 0xFF); if (getCondFlag(op1) == true) { tState = 17; mem.setCell(SP, high); mem.setCell(SP-1, low); setRPVal((byte)3,SP - 2,true); PC = addr-2; } regChanged |= regM;} catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} finally {PC+=2;} break;
/*rX add*/  case 192: case 200: case 208: case 216: case 224: case 232: case 240: case 248: op1 = (byte)((instr & 56)>>>3); tState = 5; try { if (getCondFlag(op1) == true) { tState = 11; low = mem.getCell(SP); high = mem.getCell(SP+1); PC = ((int)((high << 8) | low) & 0xFFFF); setRPVal((byte)3, SP + 2, true);} } catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} break;
/*rst n*/   case 199: case 207: case 215: case 223: case 231: case 239: case 247: case 255: op1 = (byte)((instr & 56)>>>3); tState = 11; addr = op1 * 8; high = (short)((PC >>> 8) & 0xFF); low = (short)(PC & 0xFF); try { mem.setCell(SP-1, high); mem.setCell(SP-2, low); setRPVal((byte)3, SP - 2,true); PC = (addr & 0xFFFF);regChanged |= regM; } catch(IndexOutOfBoundsException e) {running = false; reasonStopped = rsnEnum.reasonBadAddress;} break;
            default: definite = false;
        }
        if (definite == false) { running = false; reasonStopped = rsnEnum.reasonBadInstruction; }
        if (PC > 0xFFFF) { PC &= 0xFFFF; running = false; reasonStopped = rsnEnum.reasonBadAddress; }
        if (running == false) regChanged |= stoppedChanged;
        regChanged |= regPC;
        return tState;
    }
    
    /* event zmeny stavu procesora - implementacia listeners */
    public class cpuChangeStateEvent extends EventObject {
        public cpuChangeStateEvent(Object source) {
            super(source);
        }
    }
    public interface cpuChangeStateListener extends EventListener {
        public void cpuPC_change(cpuChangeStateEvent evt);
        public void cpuSP_change(cpuChangeStateEvent evt);
        public void cpuB_change(cpuChangeStateEvent evt);
        public void cpuC_change(cpuChangeStateEvent evt);
        public void cpuD_change(cpuChangeStateEvent evt);
        public void cpuE_change(cpuChangeStateEvent evt);
        public void cpuH_change(cpuChangeStateEvent evt);
        public void cpuL_change(cpuChangeStateEvent evt);
        public void cpuA_change(cpuChangeStateEvent evt);
        public void cpuPSW_change(cpuChangeStateEvent evt);
        public void cpuMem_change(cpuChangeStateEvent evt);
        public void cpuStopped(cpuChangeStateEvent evt);
        public void cpuRunned(cpuChangeStateEvent evt);
    }
    public void addCpuChangeStateListener(cpuChangeStateListener listener) {
        listenerList.add(cpuChangeStateListener.class, listener);
    }
    public void removeCpuChangeStateListener(cpuChangeStateListener listener) {
        listenerList.remove(cpuChangeStateListener.class, listener);
    }
    private void fireCpuChangeStateEvent(cpuChangeStateEvent evt, int index) {
        Object[] listeners = listenerList.getListenerList();
        for (int i=0; i<listeners.length; i+=2) {
            if (listeners[i] == cpuChangeStateListener.class) {
                if ((index & regPC)!=0) ((cpuChangeStateListener)listeners[i+1]).cpuPC_change(evt);
                if ((index & regSP)!=0) ((cpuChangeStateListener)listeners[i+1]).cpuSP_change(evt);
                if ((index & regB)!=0) ((cpuChangeStateListener)listeners[i+1]).cpuB_change(evt);
                if ((index & regC)!=0) ((cpuChangeStateListener)listeners[i+1]).cpuC_change(evt);
                if ((index & regD)!=0) ((cpuChangeStateListener)listeners[i+1]).cpuD_change(evt);
                if ((index & regE)!=0) ((cpuChangeStateListener)listeners[i+1]).cpuE_change(evt);
                if ((index & regH)!=0) ((cpuChangeStateListener)listeners[i+1]).cpuH_change(evt);
                if ((index & regL)!=0) ((cpuChangeStateListener)listeners[i+1]).cpuL_change(evt);
                if ((index & regA)!=0) ((cpuChangeStateListener)listeners[i+1]).cpuA_change(evt);
                if ((index & regM)!=0) ((cpuChangeStateListener)listeners[i+1]).cpuMem_change(evt);
                if ((index & regPSW)!=0) ((cpuChangeStateListener)listeners[i+1]).cpuPSW_change(evt);
                if ((index & stoppedChanged)!=0) {
                    if (running == true) ((cpuChangeStateListener)listeners[i+1]).cpuRunned(evt);
                    else ((cpuChangeStateListener)listeners[i+1]).cpuStopped(evt);
                }
            }
        }
    }
}
