/*
 * compiler.java
 *
 * Created on Streda, 2007, marec 14, 21:39
 *
 * KEEP IT SIMPLY STUPID
 *
 * GRAMATIKA ASSEMBLERA pre procesor 8080
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 * S -> { comment | eol } org_def { keyword | comment | org_def | eol } eof
 * org_def ->  �org� Addr eol
 * blank -> { � � | �\t� }
 * comment -> �;� [^\r\n]* eol
 * eol -> (�\r� | �\n� | �\r\n�)
 *
 * 2 byty
 * Addr -> deka | hexa | octal | binary
 * Number -> deka | hexa | octal | binary | char
 * keyword -> instruction eol | id �:� | variable | constant
 * deka ->  (0 | [1-9][0-9]*) [�d�]
 * hexa -> [0-9a-fA-F][0-9a-fA-F]* �h�
 * octal -> 0[0-7]* [�o�]
 * binary -> [0-1][0-1]* �b�
 * instruction -> �mov� (reg �,� regM | regM �,� reg)
 *  | (�lda� | "sta" | "lhld" | "shld" | "jmp" | "jnz" | "jz" | "jnc" | "jc" | "jpo" | "jpe" | "jp" | "jm" 
     | "call" | "cnz" | "cz" | "cnc" | "cc" | "cpo" | "cpe" | "cp" | "cm") (Addr | id)
 *  | (�in� | "out" | "adi" | "aci" | "sui" | "sbi" | "cpi" | "ani" | "ori" | "xri") Number
 *  | (�add� | �adc� | "sub" | �sbb� | �inr� | �dcr� | �cmp� | �ana� | �ora� | �xra�) regM 
 *  | (�ldax� | �stax�) regpBD
 *  | (�pop� | �push�) regpBDHP
 *  | (�dad� | �inx� | �dcx�) regpair
 *  | �mvi� reg �,� Number | �lxi� regpBDHS �,� Addr
 *  | �xchg� | �sphl� | �xthl� | �daa� | �cma� | �rlc� | �rrc� | �ral� | �rar� | �stc� | �cmc� | �pchl� | �ret� 
 *  | "rnz" | "rz" | "rnc" | "rc" | "rpo" | "rpe" | "rp" | "rm" | "ei" | "di" | "hlt" | "nop" | �rst� (deka | hexa | octal | binary)
 * id -> [a-zA-Z_][a-zA-Z_0-9]*
 * variable -> (�db� | �dw�) Number
 * constant -> id �equ� Number eol
 * reg -> (�a� | �b� | �c� | �d� | �e� | �h� | �l�)
 * regM -> (�a� | �b� | �c� | �d� | �e� | �h� | �l� | �m�)
 * regpBD -> (�bc� | �de�)
 * regpBDHS -> (�bc� | �de� | �hl� | �sp�)
 * regpBDHP -> (�bc� | �de� | �hl� | �psw�)
 * regpair -> (�bc� | �de� | �hl� | �sp� | �psw�)
 * char -> ��� [^���] ���
 *
 * Mnoziny zotavenia:
 * H(char) = { "'" }
 * H(regpair) = { LEX_REGBC, LEX_REGDE, LEX_REGHL, LEX_REGSP, LEX_REGPSW }
 * H(regpBDHP) = { LEX_REGBC, LEX_REGDE, LEX_HL, LEX_PSW }
 * H(regpBDHS) = { LEX_BC, LEX_DE, LEX_HL, LEX_SP }
 * H(regpBD) = { LEX_BC, LEX_DE }
 * H(regM) = { LEX_REGA, LEX_REGB, LEX_REGC, LEX_REGD, LEX_REGE, LEX_REGH, LEX_REGL, LEX_REGM }
 * H(reg) = { LEX_REGA, LEX_REGB, LEX_REGC, LEX_REGD, LEX_REGE, LEX_REGH, LEX_REGL }
 *  ??H(id) = { ("a"-"z"), ("A"-"Z") }
 * H(constant) = { LEX_ID }
 * H(variable) = { LEX_DB, LEX_DW }
 * H(instruction) = { LEX_MOV, LEX_LDA, LEX_STA, LEX_LDAX, LEX_STAX, LEX_LHDL, LEX_SHLD, LEX_XCHG, LEX_MVI, LEX_LXI,
       LEX_SPHL, LEX_XTHL, LEX_POP, LEX_PUSH, LEX_IN, LEX_OUT, LEX_ADD, LEX_ADI, LEX_ADC, LEX_ACI,
       LEX_DAD, LEX_SBB, LEX_SBI, LEX_INR, LEX_INX, LEX_DCR, LEX_DCX, LEX_CMP, LEX_CPI, LEX_DAA, LEX_ANA,
       LEX_ANI, LEX_ORA, LEX_ORI, LEX_XRA, LEX_XRI, LEX_CMA, LEX_RLC, LEX_RRC, LEX_RAL, LEX_RAR, LEX_STC,
       LEX_CMC, LEX_PCHL, LEX_JMP, LEX_CALL, LEX_RET, LEX_RST }
 * H(keyword) = H(instruction) U H(variable) U H(constant) U { LEX_ID } = { LEX_MOV,...,LEX_RST, LEX_DB, LEX_DW, LEX_ID }
 * H(org_def) = { LEX_ORG }
 * H(S) = H(org_def) U H(keyword) U { LEX_EOF } = { LEX_ORG, LEX_MOV,...,LEX_RST, LEX_DB, LEX_DW, LEX_ID, LEX_EOF }
 *
 */

package proc8080;

import devices.*;
import java.util.*;
import java.lang.Exception.*;
import java.lang.Character;
import javax.swing.*;
import javax.swing.text.*;

/**
 *
 * @author vbmacher
 */
public class asmCompiler {
    public static final int LEX_EOF = 0,     // koniec vstupu
            LEX_EOL = 1,     // \n, \r, \r\n
            LEX_ORG = 2,     // "org"
            LEX_ADDR = 3,    // 2 byty ciselna konstanta
            LEX_NUM = 4,     // 1 byte ciselna konstanta
            LEX_COLON = 5,   // ":"
            LEX_SEPARATOR = 73, // ","
            LEX_MOV = 6, LEX_LDA = 7, LEX_STA = 8, LEX_LDAX = 9, LEX_STAX = 10, LEX_LHLD = 11,
            LEX_SHLD = 12, LEX_XCHG = 13, LEX_MVI = 14, LEX_LXI = 15, LEX_SPHL = 16, LEX_XTHL = 17,
            LEX_POP = 18, LEX_PUSH = 19, LEX_IN = 20, LEX_OUT = 21, LEX_ADD = 22, LEX_ADI = 23, LEX_ADC = 24,
            LEX_ACI = 25, LEX_DAD = 26, LEX_SUB = 27, LEX_SUI = 28, LEX_SBB = 29, LEX_SBI = 30, LEX_INR = 31,
            LEX_INX = 32, LEX_DCR = 33, LEX_DCX = 34, LEX_CMP = 35, LEX_CPI = 36, LEX_DAA = 37, LEX_ANA = 38,
            LEX_ANI = 39, LEX_ORA = 40, LEX_ORI = 41, LEX_XRA = 42, LEX_XRI = 43, LEX_CMA = 44, LEX_RLC = 45,
            LEX_RRC = 46, LEX_RAL = 47, LEX_RAR = 48, LEX_STC = 49, LEX_CMC = 50, LEX_PCHL = 51, LEX_JMP = 52,
            LEX_JNZ = 53, LEX_JZ = 54, LEX_JNC = 55, LEX_JC = 56, LEX_JPO = 57, LEX_JPE = 58, LEX_JP = 59,
            LEX_JM = 60, LEX_CALL = 61, LEX_CNZ = 62, LEX_CZ = 63, LEX_CNC = 64, LEX_CC = 65, LEX_CPO = 66,
            LEX_CPE = 67, LEX_CP = 68, LEX_CM = 69, LEX_RET = 70, LEX_RNZ = 71, LEX_RZ = 72, LEX_RNC = 73,
            LEX_RC = 74, LEX_RPO = 75, LEX_RPE = 76, LEX_RP = 77, LEX_RM = 78, LEX_RST = 79, LEX_EI = 80,
            LEX_DI = 81, LEX_HLT = 82,
            LEX_NOP = 83,   // instrukcie
            LEX_ID = 84,    // identifikator
            LEX_EQU = 85,   // "equ"
            LEX_DB = 86, LEX_DW = 87,    // premenne
            LEX_REGA = 88, LEX_REGB = 89, LEX_REGC = 90, LEX_REGD = 91, LEX_REGE = 92, LEX_REGH = 93, LEX_REGL = 94,
            LEX_REGM = 95, LEX_REGBC = 96, LEX_REGDE = 97, LEX_REGHL = 98, LEX_REGSP = 99, LEX_REGPSW = 100, // registre

            /* skupiny symbolov */
            LEX_KEYWORD = 101, LEX_REGS = 102, LEX_UNKNOWN = 255;
    
    private Memory mem;
    private javax.swing.text.JTextComponent in;
    private javax.swing.text.JTextComponent out;
    private boolean showOutput;
    private boolean compileSuccess;
    
    /* zdrojovy kod */
    private int pos;
    private int col, row;
    
    /* lex. analyzator */
    private int symbol;
    private int symbol_group; // skupina, do ktorej patri symbol
    private ArrayList constTable; // tabulka konstant
    private ArrayList idTable;    // tabulka identifikatorov
    private int idIndex;
    private int constIndex;
    
    /* kompilacia */
    private int memoryPosition;
    private ArrayList idReplacements; // druhy prechod kompilatora
    private ArrayList idDefinitions;  // druhy prechod kompilatora

    /* post-kompilacia */
    private int programStart;
    private boolean programInitialized;
    private int firstInstruction;
    
    /** Creates a new instance of compiler */
    public asmCompiler(Memory m, javax.swing.JTextPane i, javax.swing.JTextArea o, boolean showOutput) {
        this.mem = m;
        this.in = i;
        this.out = o;
        this.showOutput = showOutput;
        pos = 0;
        col = row = 0;
        symbol = LEX_EOF;
        symbol_group = LEX_UNKNOWN;
        compileSuccess = false;
        constTable = new ArrayList();
        idTable = new ArrayList();
        idReplacements = new ArrayList();
        idDefinitions = new ArrayList();
        programInitialized = false;
        programStart = 0;
        memoryPosition = 0;
    }
    
    private char getChar(int posit) {
        char c = '\0';
        try { c = in.getText(posit,1).toLowerCase().charAt(0); }
        catch (BadLocationException e) {}
        finally { return c; }
    }
    
    private void updatePosition() {
        try {
            Element root = in.getDocument().getDefaultRootElement();
            row = root.getElementIndex(pos) + 1;
        } catch (NullPointerException e) {
            row = 0;
        }
        try {
            col = pos - Utilities.getRowStart(in,pos);
        } catch(BadLocationException e) {
            try {col = pos - Utilities.getRowStart(in,pos-2) -1 ;}
            catch(BadLocationException f) { col = -1; };
        }
    }
    
    private void err(int errno, String sym) {
        int ppos;
        String message;
        try {
            ppos = out.getDocument().getLength();
            message = "Chyba ["+String.valueOf(row)+","+String.valueOf(col)+"]: ";

            switch (errno) {
                case 0: message += "Ch�ba symbol: "+sym; break;
                case 1: message += "Neplatn� tvar ��selnej kon�tanty ("+sym+")"; break;
                case 2: message += "Neplatn� ve�kos� ��selnej kon�tanty ("+sym+")"; break;
                case 3: message += "Nedovolen� symbol ("+sym+")"; break;
                case 4: message += "O�ak�val sa symbol: "+sym; break;
                case 5: message += "Prv� operand sa o�ak�val symbol: "+sym; break;
                case 6: message += "Druh� operand sa o�ak�val symbol: "+sym; break;
                case 7: message += "Operand sa o�ak�val symbol: "+sym; break;
                case 8: message += "Neplatne ukon�en� program";break;
                case 9: message += "Nezn�ma in�trukcia"; break;
                case 10: message += "Nezn�me k���ov� slovo"; break;
                case 11: message += "Nedefinovan� identifik�tor: "+sym; break;
                case 12: message += "Identifk�tor u� je definovan�: "+sym;break; // 2. prechod
                default: message += "Nezn�ma chyba";break;
            }
            out.getDocument().insertString(ppos,message+"\n",null);
        } catch (BadLocationException e) {}
        compileSuccess = false;
    }
    
    /* funkcia error - zotavenie syntaktickeho analyzatora */
    private void error(int errno, String sym, Set symbolset) {
        err(errno, sym); 
        while (symbolset.contains(symbol) == false)
            getsymbol();
    }
    
    /* funkcia check - zotavenie syntaktickeho analyzatora */
    private void check(int errno, String sym, Set symbolset) {
        if (symbolset.contains(symbol) == false)
            error(errno, sym, symbolset);
    }
    
    /* lexikalny analyzator */
    private void getsymbol() {
        int hod;
        char c,i;
        String tmp; /* docasna konstanta - hodnota, identifikator */

        while(true){
	    c = getChar(pos++);
            updatePosition();
	    switch(c) {
                case '\0': symbol = LEX_EOF; symbol_group = LEX_UNKNOWN; return;
                case ';':  do { c = getChar(pos++); } while (c != '\n' && c != '\r' && c != '\0'); pos--; updatePosition(); break;
                case ' ': break;
                case '\'': 
                        c = getChar(pos++);
                        updatePosition();
                        if (getChar(pos) != '\'') err(0,"'");
                        else { pos++; updatePosition(); }
                        symbol = LEX_NUM;
                        symbol_group = LEX_UNKNOWN;
                        constTable.add((int)c);
                        constIndex = constTable.size()-1;
                        return;
                case '\t': break;
                case '\r': if (getChar(pos) == '\n') { pos++; updatePosition(); } symbol = LEX_EOL; symbol_group = LEX_UNKNOWN; return;
                case '\n': symbol = LEX_EOL; symbol_group = LEX_UNKNOWN; return;
                case ',': symbol = LEX_SEPARATOR; symbol_group = LEX_UNKNOWN; return;
                case ':': symbol = LEX_COLON; symbol_group = LEX_UNKNOWN; return;
                default:
                    tmp = "";
		    if (Character.isDigit(c)) {
                        hod = 0;
                        i = c;
                        do { c = i; tmp += c; i = getChar(pos++); } while (Character.isDigit(i) || (i >= 'a' && i <= 'f'));
                        updatePosition();
                        // dalsi znak by mal byt dodefinovanie ciselnej sustavy. ak nie je,
                        // ide o desiatkovu sustavu a znak sa vrati spat
                        switch (i) {
                            case 'h':
                                // hexadecimalne konstanta
                                try { hod = Integer.parseInt(tmp,16); }
                                catch (NumberFormatException e) { err(1, "hexadecim�lny"); }
                                break;
                            case 'o':
                                // osmickova konstanta
                                try { hod = Integer.parseInt(tmp,8); }
                                catch (NumberFormatException e) { err(1,"osmi�kov�"); }
                                break;
                            default:
                                // default je dekadicka alebo binarna
                                pos--;
                                switch (c) {
                                    case 'd':
                                        // desiatkova konstanta
                                        try { tmp=tmp.substring(0,tmp.length()-1);  hod = Integer.parseInt(tmp,10); }
                                        catch (NumberFormatException e) { err(1,"desiatkov�"); }
                                        break;
                                    case 'b':
                                        // binarna konstanta
                                        try { tmp=tmp.substring(0,tmp.length()-1); hod = Integer.parseInt(tmp,2); }
                                        catch (NumberFormatException e) { err(1,"bin�rny"); }
                                        break;
                                    default:                                
                                        try { hod = Integer.parseInt(tmp,10); }
                                        catch (NumberFormatException e) { err(1,"desiatkov�"); }
                                        break;
                                }
                        }
                        if (hod > 255 && hod < 65536) symbol = LEX_ADDR;
                        else if (hod < 256) symbol = LEX_NUM;
                        else { symbol = LEX_ADDR; err(2,"max. ��slo je 65535"); }
                        symbol_group = LEX_UNKNOWN;
                        constTable.add(hod);
                        constIndex = constTable.size()-1;
                        return;
                    }  else if (Character.isLetter(c)) {
                        // bud klucove slovo, alebo identifikator
			do { tmp +=c; c=getChar(pos++); } while (Character.isLetterOrDigit(c));
                        pos--;
                        updatePosition();
                        if (tmp.equals("org")) { symbol = LEX_ORG; symbol_group = LEX_UNKNOWN; }
                        else if (tmp.equals("mov")) { symbol = LEX_MOV; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("lda")) { symbol = LEX_LDA;  symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("sta")) { symbol = LEX_STA; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("ldax")) { symbol = LEX_LDAX; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("stax")) { symbol = LEX_STAX; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("lhld")) { symbol = LEX_LHLD; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("shld")) { symbol = LEX_SHLD; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("xchg")) { symbol = LEX_XCHG; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("mvi")) { symbol = LEX_MVI; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("lxi")) { symbol = LEX_LXI; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("sphl")) { symbol = LEX_SPHL; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("xthl")) { symbol = LEX_XTHL; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("pop")) { symbol = LEX_POP; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("push")) { symbol = LEX_PUSH; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("in")) { symbol = LEX_IN; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("out")) { symbol = LEX_OUT; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("add")) { symbol = LEX_ADD; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("adi")) { symbol = LEX_ADI; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("adc")) { symbol = LEX_ADC; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("aci")) { symbol = LEX_ACI; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("dad")) { symbol = LEX_DAD; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("sub")) { symbol = LEX_SUB; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("sui")) { symbol = LEX_SUI; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("sbb")) { symbol = LEX_SBB; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("sbi")) { symbol = LEX_SBI; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("inr")) { symbol = LEX_INR; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("inx")) { symbol = LEX_INX; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("dcr")) { symbol = LEX_DCR; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("dcx")) { symbol = LEX_DCX; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("cmp")) { symbol = LEX_CMP; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("cpi")) { symbol = LEX_CPI; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("daa")) { symbol = LEX_DAA; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("ana")) { symbol = LEX_ANA; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("ani")) { symbol = LEX_ANI; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("ora")) { symbol = LEX_ORA; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("ori")) { symbol = LEX_ORI; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("xra")) { symbol = LEX_XRA; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("xri")) { symbol = LEX_XRI; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("cma")) { symbol = LEX_CMA; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("rlc")) { symbol = LEX_RLC; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("rrc")) { symbol = LEX_RRC; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("ral")) { symbol = LEX_RAL; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("rar")) { symbol = LEX_RAR; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("stc")) { symbol = LEX_STC; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("cmc")) { symbol = LEX_CMC; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("pchl")) { symbol = LEX_PCHL; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("jmp")) { symbol = LEX_JMP; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("jnz")) { symbol = LEX_JNZ; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("jz")) { symbol = LEX_JZ; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("jnc")) { symbol = LEX_JNC; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("jc")) { symbol = LEX_JC; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("jpo")) { symbol = LEX_JPO; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("jpe")) { symbol = LEX_JPE; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("jp")) { symbol = LEX_JP; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("jm")) { symbol = LEX_JM; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("call")) { symbol = LEX_CALL; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("cnz")) { symbol = LEX_CNZ; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("cz")) { symbol = LEX_CZ; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("cnc")) { symbol = LEX_CNC; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("cc")) { symbol = LEX_CC; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("cpo")) { symbol = LEX_CPO; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("cpe")) { symbol = LEX_CPE; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("cp")) { symbol = LEX_CP; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("cm")) { symbol = LEX_CM; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("ret")) { symbol = LEX_RET; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("rnz")) { symbol = LEX_RNZ; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("rz")) { symbol = LEX_RZ; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("rnc")) { symbol = LEX_RNC; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("rc")) { symbol = LEX_RC; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("rpo")) { symbol = LEX_RPO; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("rpe")) { symbol = LEX_RPE; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("rp")) { symbol = LEX_RP; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("rm")) { symbol = LEX_RM; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("rst")) { symbol = LEX_RST; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("ei")) { symbol = LEX_EI; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("di")) { symbol = LEX_DI; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("hlt")) { symbol = LEX_HLT; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("nop")) { symbol = LEX_NOP; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("equ")) { symbol = LEX_EQU; symbol_group = LEX_UNKNOWN; }
                        else if (tmp.equals("db")) { symbol = LEX_DB; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("dw")) { symbol = LEX_DW; symbol_group = LEX_KEYWORD; }
                        else if (tmp.equals("a")) { symbol = LEX_REGA; symbol_group = LEX_REGS; }
                        else if (tmp.equals("b")) { symbol = LEX_REGB; symbol_group = LEX_REGS; }
                        else if (tmp.equals("c")) { symbol = LEX_REGC; symbol_group = LEX_REGS; }
                        else if (tmp.equals("d")) { symbol = LEX_REGD; symbol_group = LEX_REGS; }
                        else if (tmp.equals("e")) { symbol = LEX_REGE; symbol_group = LEX_REGS; }
                        else if (tmp.equals("h")) { symbol = LEX_REGH; symbol_group = LEX_REGS; }
                        else if (tmp.equals("l")) { symbol = LEX_REGL; symbol_group = LEX_REGS; }
                        else if (tmp.equals("m")) { symbol = LEX_REGM; symbol_group = LEX_REGS; }
                        else if (tmp.equals("bc")) { symbol = LEX_REGBC; symbol_group = LEX_REGS; }
                        else if (tmp.equals("de")) { symbol = LEX_REGDE; symbol_group = LEX_REGS; }
                        else if (tmp.equals("hl")) { symbol = LEX_REGHL; symbol_group = LEX_REGS; }
                        else if (tmp.equals("sp")) { symbol = LEX_REGSP; symbol_group = LEX_REGS; }
                        else if (tmp.equals("psw")) { symbol = LEX_REGPSW; symbol_group = LEX_REGS; }
                        else {
                            symbol = LEX_ID;
                            symbol_group = LEX_KEYWORD;
                            idIndex = idTable.indexOf(tmp);
                            if (idIndex == -1) {
                                idTable.add(tmp);
                                idIndex = idTable.size()-1;
                            }
                        }
			return;
		} else {
                    err(3, String.valueOf(c));
		    break;
		}
            }
	}
    }
    
    /* syntakticky analyzator */

    /* org_def ->  �org� Addr eol */
    private void org_def(Set symbolset) {
        Set syms = new HashSet();
        syms.addAll(symbolset);
        syms.add(LEX_NUM);
        syms.add(LEX_ADDR);
        syms.add(LEX_EOL);
        if (symbol == LEX_ORG) getsymbol();
        else error(4,"ORG",syms);
        if (symbol == LEX_ADDR || symbol == LEX_NUM) {
            // TODO: kontrola pripadna
            memoryPosition = Integer.valueOf(constTable.get(constIndex).toString()); 
            if (programInitialized == false) {
                programStart = memoryPosition;
                programInitialized = true;
            }
            getsymbol();
        } else {
            syms = new HashSet();
            syms.addAll(symbolset);
            syms.add(LEX_EOL);
            error(4,"��seln� kon�tanta",syms);
        }
        if (symbol == LEX_EOL) getsymbol();
        else error(4,"nov� riadok",symbolset);
    }

    /* variable -> (�db� | �dw�) Number */
    private void variable(Set symbolset) {
        Set syms = new HashSet();
        syms.addAll(symbolset);
        syms.add(LEX_DB);
        syms.add(LEX_DW);
        check(4, "DB alebo DW", syms);
        if (symbol == LEX_DB) {
            getsymbol();
            if (symbol == LEX_NUM) {
                // definicia bytu
                mem.setCell(memoryPosition++,Short.valueOf(constTable.get(constIndex).toString()));
                getsymbol();
            } else {
                if (symbol == LEX_ADDR) error(2, "max. ��slo je 255",symbolset);
                else error(4,"��seln� kon�tanta",symbolset);
            }
        } else if (symbol == LEX_DW) {
            getsymbol();
            if (symbol == LEX_NUM || symbol == LEX_ADDR) {
                // definicia slova
                mem.setCellWord(memoryPosition, Integer.valueOf(constTable.get(constIndex).toString())); memoryPosition += 2;
                getsymbol();
            } else error(4,"��seln� kon�tanta",symbolset);
        } else error(4, "DB alebo DW", syms);
    }
    
    /* constant -> id �equ� Number eol */
    private void constant(Set symbolset) {
        Set syms = new HashSet();
        syms.addAll(symbolset);
        syms.add(LEX_EQU);
        syms.add(LEX_NUM);
        syms.add(LEX_ADDR);
        syms.add(LEX_EOL);
        if (symbol == LEX_ID) getsymbol();
        else error(4, "identifik�tor",syms);
        if (symbol == LEX_EQU) getsymbol();
        else {
            syms = new HashSet();
            syms.addAll(symbolset);
            syms.add(LEX_NUM);
            syms.add(LEX_ADDR);
            syms.add(LEX_EOL);
            error(4, "EQU",syms);
        }
        if (symbol == LEX_ADDR || symbol == LEX_NUM) {
            // def. konstanty ??
            getsymbol();
        } else {
            syms = new HashSet();
            syms.addAll(symbolset);
            syms.add(LEX_EOL);
            error(4, "��seln� kon�tanta",syms);
        }
        if (symbol == LEX_EOL) getsymbol();
        else error(4, "nov� riadok",symbolset);
    }
    
    private short tmpGetReg(int operand) {
        switch (symbol) {
            case LEX_REGBC:
            case LEX_REGB: return 0;
            case LEX_REGDE:
            case LEX_REGC: return 1;
            case LEX_REGHL:
            case LEX_REGD: return 2;
            case LEX_REGSP:
            case LEX_REGPSW:
            case LEX_REGE: return 3;
            case LEX_REGH: return 4;
            case LEX_REGL: return 5;
            case LEX_REGM: return 6;
            case LEX_REGA: return 7;
            default: return 0;
        }
    }
    
    // metoda prida potrebne upravy pre druhy prechod kompilovania
    /*
     * idReplacements = arraylist pozostavajuci z poli, ktoreho polozky su:
     *    [0] => index v tabulke identifikatorov (teda identifikator)
     *    [1] => adresa v pamati
     *
     * identifikuje zmeny, ktore treba urobit po kompilacii (nastavit absolutne adresy)
     */
    private void addReplacement(int id_id, int mem_loc) {
        int[] r;
        for (int i = 0; i < idReplacements.size(); i++) {
            r = (int[])idReplacements.get(i);
            if ((r != null) && ((r[0] == id_id) && (r[1] == mem_loc))) {
                // keby sa sem dostal bolo by to fakt cudne
                return;
            }
        }
        r = new int[2];
        r[0] = id_id; r[1] = mem_loc;
        idReplacements.add(r);
    }
    
    /* pri definicii identifikatora sa prida do arraylistu pole s 2 polozkami:
     *   [0] => index v TID
     *   [1] => repConst = nahrada
     */
    private void addDefinition(int id_id, int repConst) {
        int[] r;
        for (int i = 0; i < idDefinitions.size(); i++) {
            r = (int[])idDefinitions.get(i);
            if ((r != null) && ((r[0] == id_id) && (r[1] == repConst))) {
                // chyba: 2 krat deklarovany identifikator !!
                err(12,idTable.get(id_id).toString());
                return;
            }
        }
        r = new int[2];
        r[0] = id_id;
        r[1] = repConst;
        idDefinitions.add(r);
    }
    
    
    private void instruction(Set symbolset) {
        Set syms = new HashSet(),syms1;
        short op1 = 0, op2 = 0; // operandy
        short byte1 = 0, byte2 = 0; // prelozene instrukcie
        boolean con = false, con2 = false; // pomocne podmienky
        syms.addAll(symbolset);
        syms.add(LEX_MOV); syms.add(LEX_LDA); syms.add(LEX_STA); syms.add(LEX_LDAX); syms.add(LEX_STAX);
        syms.add(LEX_LHLD); syms.add(LEX_SHLD); syms.add(LEX_XCHG); syms.add(LEX_MVI); syms.add(LEX_LXI);
        syms.add(LEX_SPHL); syms.add(LEX_XTHL); syms.add(LEX_POP); syms.add(LEX_PUSH); syms.add(LEX_IN);
        syms.add(LEX_OUT); syms.add(LEX_ADD); syms.add(LEX_ADI); syms.add(LEX_ADC); syms.add(LEX_ACI);
        syms.add(LEX_DAD); syms.add(LEX_SUB); syms.add(LEX_SUI); syms.add(LEX_SBB); syms.add(LEX_SBI);
        syms.add(LEX_INR); syms.add(LEX_INX); syms.add(LEX_DCR); syms.add(LEX_DCX); syms.add(LEX_CMP);
        syms.add(LEX_CPI); syms.add(LEX_DAA); syms.add(LEX_ANA); syms.add(LEX_ANI); syms.add(LEX_ORA);
        syms.add(LEX_ORI); syms.add(LEX_XRA); syms.add(LEX_XRI); syms.add(LEX_CMA); syms.add(LEX_RLC);
        syms.add(LEX_RRC); syms.add(LEX_RAL); syms.add(LEX_RAR); syms.add(LEX_STC); syms.add(LEX_CMC);
        syms.add(LEX_PCHL); syms.add(LEX_JMP); syms.add(LEX_JNZ); syms.add(LEX_JZ); syms.add(LEX_JNC);
        syms.add(LEX_JC); syms.add(LEX_JPO); syms.add(LEX_JPE); syms.add(LEX_JP); syms.add(LEX_JM);
        syms.add(LEX_CALL); syms.add(LEX_CNZ); syms.add(LEX_CZ); syms.add(LEX_CNC); syms.add(LEX_CC);
        syms.add(LEX_CPO); syms.add(LEX_CPE); syms.add(LEX_CP); syms.add(LEX_CM); syms.add(LEX_RET);
        syms.add(LEX_RNZ); syms.add(LEX_RZ); syms.add(LEX_RNC); syms.add(LEX_RC); syms.add(LEX_RPO);
        syms.add(LEX_RPE); syms.add(LEX_RP); syms.add(LEX_RM); syms.add(LEX_EI); syms.add(LEX_DI);
        syms.add(LEX_HLT); syms.add(LEX_NOP); syms.add(LEX_RST);
        check(9,null,syms);
        switch (symbol) {
            case LEX_MOV:
                getsymbol();
                syms1 = new HashSet();
                syms1.addAll(symbolset);
                syms1.add(LEX_REGA); syms1.add(LEX_REGB); syms1.add(LEX_REGC); syms1.add(LEX_REGD); syms1.add(LEX_REGE);
                syms1.add(LEX_REGH); syms1.add(LEX_REGL); syms1.add(LEX_REGM);
                check(5,"register A-E,H,L alebo M", syms1);
                if (symbol == LEX_REGA || symbol == LEX_REGB || symbol == LEX_REGC || symbol == LEX_REGD || symbol == LEX_REGE
                        || symbol == LEX_REGH || symbol == LEX_REGL) {
                    op1 = tmpGetReg(symbol);
                    getsymbol();
                    if (symbol == LEX_SEPARATOR) getsymbol();
                    else error(4,"odde�ova� operandov - �iarka ','",syms1);
                    if (symbol == LEX_REGA || symbol == LEX_REGB || symbol == LEX_REGC || symbol == LEX_REGD || symbol == LEX_REGE
                            || symbol == LEX_REGH || symbol == LEX_REGL || symbol == LEX_REGM) {
                        op2 = tmpGetReg(symbol);
                        // mov reg, regM
                        byte1 = (short)(64 | (short)((short)(op1 & 7) << 3) | (short)(op2 & 7));
                        mem.setCell(memoryPosition++, byte1);
                        getsymbol();
                    } else error(6, "register A-E,H,L alebo M", symbolset);
                } else if (symbol == LEX_REGM) {
                    getsymbol();
                    if (symbol == LEX_SEPARATOR) getsymbol();
                    else {
                        syms1.remove(LEX_REGM);
                        error(4,"odde�ova� operandov - �iarka ','",syms1);
                    }
                    if (symbol == LEX_REGA || symbol == LEX_REGB || symbol == LEX_REGC || symbol == LEX_REGD || symbol == LEX_REGE
                            || symbol == LEX_REGH || symbol == LEX_REGL) {
                        // mov M, reg
                        op2 = tmpGetReg(symbol);
                        byte1 = (short)(112 | (short)(op2 & 7));
                        mem.setCell(memoryPosition++, byte1);
                        getsymbol();
                    } else error(6,"register A-E,H alebo L",symbolset);
                } else error(5,"register A-E,H,L alebo M",syms1);
                break;
            case LEX_LDA:  byte1 = 58; con = true;
            case LEX_STA:  if (!con) { byte1 = 50; con = true; }
            case LEX_LHLD: if (!con) { byte1 = 42; con = true; }
            case LEX_SHLD: if (!con) { byte1 = 34; con = true; }
            case LEX_JMP:  if (!con) { byte1 = 195; con = true; }
            case LEX_JNZ:  if (!con) { byte1 = 194; con = true; }
            case LEX_JZ:   if (!con) { byte1 = 202; con = true; }
            case LEX_JNC:  if (!con) { byte1 = 210; con = true; }
            case LEX_JC:   if (!con) { byte1 = 218; con = true; }
            case LEX_JPO:  if (!con) { byte1 = 226; con = true; }
            case LEX_JPE:  if (!con) { byte1 = 236; con = true; }
            case LEX_JP:   if (!con) { byte1 = 242; con = true; }
            case LEX_JM:   if (!con) { byte1 = 250; con = true; }
            case LEX_CALL: if (!con) { byte1 = 205; con = true; }
            case LEX_CNZ:  if (!con) { byte1 = 196; con = true; }
            case LEX_CZ:   if (!con) { byte1 = 204; con = true; }
            case LEX_CNC:  if (!con) { byte1 = 212; con = true; }
            case LEX_CC:   if (!con) { byte1 = 220; con = true; }
            case LEX_CPO:  if (!con) { byte1 = 228; con = true; }
            case LEX_CPE:  if (!con) { byte1 = 236; con = true; }
            case LEX_CP:   if (!con) { byte1 = 244; con = true; }
            case LEX_CM:
                if (!con) { byte1 = 252; }
                con = false;
                getsymbol();
                if (symbol == LEX_NUM || symbol == LEX_ADDR || symbol == LEX_ID) {
                    // preklad instrukcie - ak je symbol id, treba skontrolovat
                    mem.setCell(memoryPosition++, byte1);
                    if (symbol != LEX_ID) {
                        mem.setCellWord(memoryPosition, Short.valueOf(constTable.get(constIndex).toString()));
                        memoryPosition += 2;
                    } else {
                        // ked je to id, treba 2 prechody
                        addReplacement(idIndex, memoryPosition);
                        mem.setCellWord(memoryPosition, 0);
                        memoryPosition += 2;
                    }
                    getsymbol();
                } else error(7, "��seln� kon�tanta alebo identifik�tor",symbolset);
                break;
            case LEX_IN:  byte1 = 219; con = true;
            case LEX_OUT: if (!con) { byte1 = 211; con = true; }
            case LEX_ADI: if (!con) { byte1 = 198; con = true; }
            case LEX_ACI: if (!con) { byte1 = 206; con = true; }
            case LEX_SUI: if (!con) { byte1 = 214; con = true; }
            case LEX_SBI: if (!con) { byte1 = 222; con = true; }
            case LEX_CPI: if (!con) { byte1 = 254; con = true; }
            case LEX_ANI: if (!con) { byte1 = 230; con = true; }
            case LEX_ORI: if (!con) { byte1 = 246; con = true; }
            case LEX_XRI:
                if (!con) { byte1 = 238; }
                con = false;
                getsymbol();
                if (symbol == LEX_NUM) {
                    // preklad
                    mem.setCell(memoryPosition++, byte1);
                    mem.setCell(memoryPosition++, Short.valueOf(constTable.get(constIndex).toString()));
                    getsymbol();
                } else error(7, "��seln� kon�tanta",symbolset);
                break;
            case LEX_ADD: byte1 = 128; con = true; con2 = false;
            case LEX_ADC: if (!con) { byte1 = 136; con = true; con2 = false; }
            case LEX_SUB: if (!con) { byte1 = 144; con = true; con2 = false; }
            case LEX_SBB: if (!con) { byte1 = 152; con = true; con2 = false; }
            case LEX_CMP: if (!con) { byte1 = 184; con = true; con2 = false; }
            case LEX_ANA: if (!con) { byte1 = 160; con = true; con2 = false; }
            case LEX_ORA: if (!con) { byte1 = 176; con = true; con2 = false; }
            case LEX_XRA: if (!con) { byte1 = 168; con = true; con2 = false; }
            case LEX_INR: if (!con) { byte1 = 4; con = true; con2 = true; }
            case LEX_DCR:
                if (!con) { byte1 = 5; con2 = true; }
                con = false;
                getsymbol();
                if (symbol == LEX_REGA || symbol == LEX_REGB || symbol == LEX_REGC || symbol == LEX_REGD || symbol == LEX_REGE
                        || symbol == LEX_REGH || symbol == LEX_REGL || symbol == LEX_REGM) {
                    // preklad
                    op1 = tmpGetReg(symbol);
                    if (con2 == false) byte1 |= (op1 & 7);
                    else byte1 |= ((op1 & 7) << 3);
                    mem.setCell(memoryPosition++, byte1);
                    getsymbol();
                } else error(7, "register A-E,H,L alebo M", symbolset);
                break;
            case LEX_LDAX: byte1 = 10; con = true;
            case LEX_STAX:
                if (!con) byte1 = 2;
                con = false;
                getsymbol();
                if (symbol == LEX_REGBC || symbol == LEX_REGDE) {
                    // preklad
                    op1 = tmpGetReg(symbol);
                    byte1 |= ((op1 & 3) << 4);
                    mem.setCell(memoryPosition++, byte1);
                    getsymbol();
                } else error(7,"dvojica registrov BC alebo DE",symbolset);
                break;
            case LEX_POP:
                byte1 = 193; con = true;
            case LEX_PUSH:
                if (!con) byte1 = 197;
                con = false;
                getsymbol();
                if (symbol == LEX_REGBC || symbol == LEX_REGDE || symbol == LEX_REGHL || symbol == LEX_REGPSW) {
                    // preklad
                    op1 = tmpGetReg(symbol);
                    byte1 |= ((op1 & 3) << 4);
                    mem.setCell(memoryPosition++, byte1);
                    getsymbol();
                } else error(7, "dvojica registrov BC, DE, HL alebo PSW",symbolset);
                break;
            case LEX_DAD: byte1 = 9; con = true;
            case LEX_INX: if (!con) { byte1 = 3; con = true; }
            case LEX_DCX:
                if (!con) byte1 = 11;
                con = false;
                getsymbol();
                if (symbol == LEX_REGBC || symbol == LEX_REGDE || symbol == LEX_REGHL || symbol == LEX_REGSP || symbol == LEX_REGPSW) {
                    // preklad
                    op1 = tmpGetReg(symbol);
                    byte1 |= ((op1 & 3) << 4);
                    mem.setCell(memoryPosition++, byte1);
                    getsymbol();
                } else error(7, "dvojica registrov BC,DE,HL,SP alebo PSW",symbolset);
                break;
            case LEX_MVI:
                syms1 = new HashSet();
                syms1.addAll(symbolset);
                syms1.add(LEX_SEPARATOR);
                syms1.add(LEX_NUM);
                getsymbol();
                if (symbol == LEX_REGA || symbol == LEX_REGB || symbol == LEX_REGC || symbol == LEX_REGD || symbol == LEX_REGE
                        || symbol == LEX_REGH || symbol == LEX_REGL) {
                    op1 = tmpGetReg(symbol);
                    getsymbol();
                }
                else error(5, "register A-E,H alebo L",syms1);
                if (symbol == LEX_SEPARATOR) getsymbol();
                else {
                    syms1.remove(LEX_SEPARATOR);
                    error(4,"odde�ova� operandov - �iarka ','",syms1);
                }
                if (symbol == LEX_NUM) {
                    // preklad
                    byte1 = (short)(6 | ((op1 & 7) << 3));
                    mem.setCell(memoryPosition++, byte1);
                    mem.setCell(memoryPosition++, Short.valueOf(constTable.get(constIndex).toString()));
                    getsymbol();
                } else error(6,"��seln� kon�tanta",symbolset);
                break;
            case LEX_LXI:
                syms1 = new HashSet();
                syms1.addAll(symbolset);
                syms1.add(LEX_SEPARATOR);
                syms1.add(LEX_NUM);
                syms1.add(LEX_ADDR);
                syms1.add(LEX_ID);
                getsymbol();
                if (symbol == LEX_REGBC || symbol == LEX_REGDE 
                        || symbol == LEX_REGHL || symbol == LEX_REGSP) {
                    op1 = tmpGetReg(symbol);
                    getsymbol();
                }
                else error(5, "dvojica registrov BC,DE,HL alebo SP", syms1);
                if (symbol == LEX_SEPARATOR) getsymbol();
                else {
                    syms1.remove(LEX_SEPARATOR);
                    error(4,"odde�ova� operandov - �iarka ','",syms1);
                }
                if (symbol == LEX_NUM || symbol == LEX_ADDR || symbol == LEX_ID) {
                    // preklad instrukcie - ak je symbol id, treba skontrolovat
                    byte1 = (short)(1 | ((op1 & 3) << 4));
                    mem.setCell(memoryPosition++, byte1);

                    if (symbol != LEX_ID) {
                        mem.setCellWord(memoryPosition, Short.valueOf(constTable.get(constIndex).toString()));
                        memoryPosition += 2;
                    } else {
                        // ked je to id, treba 2 prechody
                        addReplacement(idIndex, memoryPosition);
                        mem.setCellWord(memoryPosition, 0);
                        memoryPosition += 2;
                    }
                    getsymbol();
                } else error(6, "��seln� kon�tanta", symbolset);
                break;
            case LEX_RST:
                getsymbol();
                if (symbol == LEX_NUM) {
                    // preklad
                    op1 = Short.valueOf(constTable.get(constIndex).toString());
                    if (op1 > 7) err(2, "max. ��slo je 7");
                    byte1 = (short)(199 | ((op1 & 7) << 3));
                    mem.setCell(memoryPosition++, byte1);
                    getsymbol();
                } else error(7, "��seln� kon�tanta",symbolset);
                break;
            case LEX_XCHG: mem.setCell(memoryPosition++, (short)235); getsymbol(); break;
            case LEX_SPHL: mem.setCell(memoryPosition++, (short)249); getsymbol(); break;
            case LEX_XTHL: mem.setCell(memoryPosition++, (short)227); getsymbol(); break;
            case LEX_DAA:  mem.setCell(memoryPosition++, (short)39); getsymbol(); break;
            case LEX_CMA:  mem.setCell(memoryPosition++, (short)47); getsymbol(); break;
            case LEX_RLC:  mem.setCell(memoryPosition++, (short)7); getsymbol(); break;
            case LEX_RRC:  mem.setCell(memoryPosition++, (short)15); getsymbol(); break;
            case LEX_RAL:  mem.setCell(memoryPosition++, (short)23); getsymbol(); break;
            case LEX_RAR:  mem.setCell(memoryPosition++, (short)31); getsymbol(); break;
            case LEX_STC:  mem.setCell(memoryPosition++, (short)55); getsymbol(); break;
            case LEX_CMC:  mem.setCell(memoryPosition++, (short)63); getsymbol(); break;
            case LEX_PCHL: mem.setCell(memoryPosition++, (short)233); getsymbol(); break;
            case LEX_RET:  mem.setCell(memoryPosition++, (short)201); getsymbol(); break;
            case LEX_RNZ:  mem.setCell(memoryPosition++, (short)192); getsymbol(); break;
            case LEX_RZ:  mem.setCell(memoryPosition++, (short)200); getsymbol(); break;
            case LEX_RNC:  mem.setCell(memoryPosition++, (short)208); getsymbol(); break;
            case LEX_RC:   mem.setCell(memoryPosition++, (short)216); getsymbol(); break;
            case LEX_RPO:  mem.setCell(memoryPosition++, (short)224); getsymbol(); break;
            case LEX_RPE:  mem.setCell(memoryPosition++, (short)232); getsymbol(); break;
            case LEX_RP:  mem.setCell(memoryPosition++, (short)240); getsymbol(); break;
            case LEX_RM:  mem.setCell(memoryPosition++, (short)248); getsymbol(); break;
            case LEX_EI:  mem.setCell(memoryPosition++, (short)251); getsymbol(); break;
            case LEX_DI:  mem.setCell(memoryPosition++, (short)243); getsymbol(); break;
            case LEX_HLT:  mem.setCell(memoryPosition++, (short)118); getsymbol(); break;
            case LEX_NOP:  mem.setCell(memoryPosition++, (short)0); getsymbol(); break;
            default: check(9,null,syms);
        }
    }
    
    /* keyword -> instruction eol | id �:� | variable | constant */
    private void keyword(Set symbolset) {
        char c;
        Set syms = new HashSet(),syms1;
        syms.addAll(symbolset);
        syms.add(LEX_MOV); syms.add(LEX_LDA); syms.add(LEX_STA); syms.add(LEX_LDAX); syms.add(LEX_STAX);
        syms.add(LEX_LHLD); syms.add(LEX_SHLD); syms.add(LEX_XCHG); syms.add(LEX_MVI); syms.add(LEX_LXI);
        syms.add(LEX_SPHL); syms.add(LEX_XTHL); syms.add(LEX_POP); syms.add(LEX_PUSH); syms.add(LEX_IN);
        syms.add(LEX_OUT); syms.add(LEX_ADD); syms.add(LEX_ADI); syms.add(LEX_ADC); syms.add(LEX_ACI);
        syms.add(LEX_DAD); syms.add(LEX_SUB); syms.add(LEX_SUI); syms.add(LEX_SBB); syms.add(LEX_SBI); syms.add(LEX_INR); syms.add(LEX_INX);
        syms.add(LEX_DCR); syms.add(LEX_DCX); syms.add(LEX_CMP); syms.add(LEX_CPI); syms.add(LEX_DAA);
        syms.add(LEX_ANA); syms.add(LEX_ANI); syms.add(LEX_ORA); syms.add(LEX_ORI); syms.add(LEX_XRA);
        syms.add(LEX_XRI); syms.add(LEX_CMA); syms.add(LEX_RLC); syms.add(LEX_RRC); syms.add(LEX_RAL);
        syms.add(LEX_RAR); syms.add(LEX_STC); syms.add(LEX_CMC); syms.add(LEX_PCHL); syms.add(LEX_JMP);
        syms.add(LEX_JNZ); syms.add(LEX_JZ); syms.add(LEX_JNC); syms.add(LEX_JC); syms.add(LEX_JPO);
        syms.add(LEX_JPE); syms.add(LEX_JP); syms.add(LEX_JM);  syms.add(LEX_CALL); syms.add(LEX_CNZ);
        syms.add(LEX_CZ); syms.add(LEX_CNC); syms.add(LEX_CC); syms.add(LEX_CPO); syms.add(LEX_CPE);
        syms.add(LEX_CP); syms.add(LEX_CM); syms.add(LEX_RET); syms.add(LEX_RNZ); syms.add(LEX_RZ);
        syms.add(LEX_RNC); syms.add(LEX_RC); syms.add(LEX_RPO); syms.add(LEX_RPE); syms.add(LEX_RP);
        syms.add(LEX_RM); syms.add(LEX_EI); syms.add(LEX_DI); syms.add(LEX_HLT); syms.add(LEX_NOP);
        syms.add(LEX_RST); syms.add(LEX_ID); syms.add(LEX_DB); syms.add(LEX_DW);
        check(10,null,syms);
        if (symbol == LEX_ID) {
            c = getChar(pos);
            if (c == ':') {
                pos++;
                updatePosition();
                // definovanie labelu - symbolickej adresy
                addDefinition(idIndex,memoryPosition);
                getsymbol();
            } else constant(symbolset);
        } else if (symbol == LEX_DB || symbol == LEX_DW) variable(symbolset);
        else {
            syms1 = new HashSet();
            syms1.addAll(symbolset);
            syms1.add(LEX_EOL);
            instruction(syms1);
            if (symbol == LEX_EOL) getsymbol();
            else error(4, "nov� riadok", symbolset);
        }
    }
    
    /* S -> { comment | eol } org_def { keyword | comment | org_def | eol } eof */
    private void S() {
        Set syms = new HashSet();
        syms.add(LEX_ORG); syms.add(LEX_MOV); syms.add(LEX_LDA); syms.add(LEX_STA); syms.add(LEX_LDAX); syms.add(LEX_STAX);
        syms.add(LEX_LHLD); syms.add(LEX_SHLD); syms.add(LEX_XCHG); syms.add(LEX_MVI); syms.add(LEX_LXI);
        syms.add(LEX_SPHL); syms.add(LEX_XTHL); syms.add(LEX_POP); syms.add(LEX_PUSH); syms.add(LEX_IN);
        syms.add(LEX_OUT); syms.add(LEX_ADD); syms.add(LEX_ADI); syms.add(LEX_ADC); syms.add(LEX_ACI);
        syms.add(LEX_DAD); syms.add(LEX_SUB); syms.add(LEX_SUI); syms.add(LEX_SBB); syms.add(LEX_SBI); syms.add(LEX_INR); syms.add(LEX_INX);
        syms.add(LEX_DCR); syms.add(LEX_DCX); syms.add(LEX_CMP); syms.add(LEX_CPI); syms.add(LEX_DAA);
        syms.add(LEX_ANA); syms.add(LEX_ANI); syms.add(LEX_ORA); syms.add(LEX_ORI); syms.add(LEX_XRA);
        syms.add(LEX_XRI); syms.add(LEX_CMA); syms.add(LEX_RLC); syms.add(LEX_RRC); syms.add(LEX_RAL);
        syms.add(LEX_RAR); syms.add(LEX_STC); syms.add(LEX_CMC); syms.add(LEX_PCHL); syms.add(LEX_JMP);
        syms.add(LEX_JNZ); syms.add(LEX_JZ); syms.add(LEX_JNC); syms.add(LEX_JC); syms.add(LEX_JPO);
        syms.add(LEX_JPE); syms.add(LEX_JP); syms.add(LEX_JM);  syms.add(LEX_CALL); syms.add(LEX_CNZ);
        syms.add(LEX_CZ); syms.add(LEX_CNC); syms.add(LEX_CC); syms.add(LEX_CPO); syms.add(LEX_CPE);
        syms.add(LEX_CP); syms.add(LEX_CM); syms.add(LEX_RET); syms.add(LEX_RNZ); syms.add(LEX_RZ);
        syms.add(LEX_RNC); syms.add(LEX_RC); syms.add(LEX_RPO); syms.add(LEX_RPE); syms.add(LEX_RP);
        syms.add(LEX_RM); syms.add(LEX_EI); syms.add(LEX_DI); syms.add(LEX_HLT); syms.add(LEX_NOP);
        syms.add(LEX_RST); syms.add(LEX_ID); syms.add(LEX_DB);
        syms.add(LEX_DW); syms.add(LEX_EOL); syms.add(LEX_EOF);

        while (symbol == LEX_EOL) getsymbol();
        check(4,"ORG",syms);
        if (symbol == LEX_ORG) org_def(syms);
        else error(4,"ORG",syms);
        
        check(10,null,syms);
        while (symbol == LEX_ORG || symbol_group == LEX_KEYWORD || symbol == LEX_EOL) {
            if (symbol == LEX_ORG) org_def(syms);
            else if (symbol_group == LEX_KEYWORD) keyword(syms);
            else if (symbol == LEX_EOL) getsymbol();
            check(10,null,syms);
        }
    }
    
    // druhy prechod - nahradi vsetky nahrady (adresy) absolutnymi adresami
    private void secondPass() {
        int r[],s[];
        int addr;
        boolean con;
        
        for (int i = 0; i < idReplacements.size(); i++) {
            r = (int[])idReplacements.get(i);
            con = false; s= null;
            for (int j = 0; j < idDefinitions.size(); j++) {
               s = (int[])idDefinitions.get(j);
               if (s[0] == r[0]) { con = true; break; }
            }
            if (con == false) err(11,idTable.get(r[0]).toString());
            else if (s != null) mem.setCellWord(r[1],s[1]);
        }
        idReplacements.clear();
    }
    
    public int getProgramStart() {
        return programStart;
    }
    
    public int getFirstInstruction() {
        return firstInstruction;
    }
    
    public boolean startCompile() {
        mem.clearMemory();
        constTable.clear();
        idTable.clear();
        idReplacements.clear();
        idDefinitions.clear();
        constIndex = idIndex = 0;
        pos = 0;
        col = row = 0;
        compileSuccess = true;
        memoryPosition = 0;
        programInitialized = false;
        programStart = firstInstruction = 0;
        getsymbol();
        S();
        if (symbol != LEX_EOF) {
            err(8,null);
            return false;
        }
        if (compileSuccess == true && idReplacements.size() > 0)
            secondPass();
        // zisti sa adresa prvej platnej instrukcie v pamati
        for (int i = 0; i < mem.getSize(); i++)
            if (mem.getCell(i) != 0) { firstInstruction = i; break; }
        return compileSuccess;
    }

    /*
     * struktura arraylistu:
     * 0 - mnemonika (string)
     * 1 - oper. kod (string)
     * 2 - dalsia instrukcia (pointer do pamate)
     */
    public ArrayList disassembleInstruction(int memPos) {
        short val;
        int addr;
        int actPos = memPos;
        ArrayList returnSet = new ArrayList();
        String mnemo, oper;
        
        val = mem.getCell(actPos++);
        switch (val) {
            case 64: mnemo = "mov B,B"; oper = "40"; break;
            case 65: mnemo = "mov B,C"; oper = "41"; break;
            case 66: mnemo = "mov B,D"; oper = "42"; break;
            case 67: mnemo = "mov B,E"; oper = "43"; break;
            case 68: mnemo = "mov B,H"; oper = "44"; break;
            case 69: mnemo = "mov B,L"; oper = "45"; break;
            case 70: mnemo = "mov B,M"; oper = "46"; break;
            case 71: mnemo = "mov B,A"; oper = "47"; break;
            case 72: mnemo = "mov C,B"; oper = "48"; break;
            case 73: mnemo = "mov C,C"; oper = "49"; break;
            case 74: mnemo = "mov C,D"; oper = "4A"; break;
            case 75: mnemo = "mov C,E"; oper = "4B"; break;
            case 76: mnemo = "mov C,H"; oper = "4C"; break;
            case 77: mnemo = "mov C,L"; oper = "4D"; break;
            case 78: mnemo = "mov C,M"; oper = "4E"; break;
            case 79: mnemo = "mov C,A"; oper = "4F"; break;
            case 80: mnemo = "mov D,B"; oper = "50"; break;
            case 81: mnemo = "mov D,C"; oper = "51"; break;
            case 82: mnemo = "mov D,D"; oper = "52"; break;
            case 83: mnemo = "mov D,E"; oper = "53"; break;
            case 84: mnemo = "mov D,H"; oper = "54"; break;
            case 85: mnemo = "mov D,L"; oper = "55"; break;
            case 86: mnemo = "mov D,M"; oper = "56"; break;
            case 87: mnemo = "mov D,A"; oper = "57"; break;
            case 88: mnemo = "mov E,B"; oper = "58"; break;
            case 89: mnemo = "mov E,C"; oper = "59"; break;
            case 90: mnemo = "mov E,D"; oper = "5A"; break;
            case 91: mnemo = "mov E,E"; oper = "5B"; break;
            case 92: mnemo = "mov E,H"; oper = "5C"; break;
            case 93: mnemo = "mov E,L"; oper = "5D"; break;
            case 94: mnemo = "mov E,M"; oper = "5E"; break;
            case 95: mnemo = "mov E,A"; oper = "5F"; break;
            case 96: mnemo = "mov H,B"; oper = "60"; break;
            case 97: mnemo = "mov H,C"; oper = "61"; break;
            case 98: mnemo = "mov H,D"; oper = "62"; break;
            case 99: mnemo = "mov H,E"; oper = "63"; break;
            case 100: mnemo = "mov H,H"; oper = "64"; break;
            case 101: mnemo = "mov H,L"; oper = "65"; break;
            case 102: mnemo = "mov H,M"; oper = "66"; break;
            case 103: mnemo = "mov H,A"; oper = "67"; break;
            case 104: mnemo = "mov L,B"; oper = "68"; break;
            case 105: mnemo = "mov L,C"; oper = "69"; break;
            case 106: mnemo = "mov L,D"; oper = "6A"; break;
            case 107: mnemo = "mov L,E"; oper = "6B"; break;
            case 108: mnemo = "mov L,H"; oper = "6C"; break;
            case 109: mnemo = "mov L,L"; oper = "6D"; break;
            case 110: mnemo = "mov L,M"; oper = "6E"; break;
            case 111: mnemo = "mov L,A"; oper = "6F"; break;
            case 112: mnemo = "mov M,B"; oper = "70"; break;
            case 113: mnemo = "mov M,C"; oper = "71"; break;
            case 114: mnemo = "mov M,D"; oper = "72"; break;
            case 115: mnemo = "mov M,E"; oper = "73"; break;
            case 116: mnemo = "mov M,H"; oper = "74"; break;
            case 117: mnemo = "mov M,L"; oper = "75"; break;
            case 119: mnemo = "mov M,A"; oper = "77"; break;
            case 120: mnemo = "mov A,B"; oper = "78"; break;
            case 121: mnemo = "mov A,C"; oper = "79"; break;
            case 122: mnemo = "mov A,D"; oper = "7A"; break;
            case 123: mnemo = "mov A,E"; oper = "7B"; break;
            case 124: mnemo = "mov A,H"; oper = "7C"; break;
            case 125: mnemo = "mov A,L"; oper = "7D"; break;
            case 126: mnemo = "mov A,M"; oper = "7E"; break;
            case 127: mnemo = "mov A,A"; oper = "7F"; break;
            case 58: // lda addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "lda "+String.format("%Xh", addr);
                 oper = "3A " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 50: // sta addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "sta "+String.format("%Xh", addr);
                 oper = "32 " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 10: mnemo = "ldax BC"; oper = "0A"; break;
            case 26: mnemo = "ldax DE"; oper = "1A"; break;
            case 2:  mnemo = "stax BC"; oper = "02"; break;
            case 18: mnemo = "stax DE"; oper = "12"; break;
            case 42: // lhld addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "lhld "+String.format("%Xh", addr);
                 oper = "2A " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 34: // shld addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "shld "+String.format("%Xh", addr);
                 oper = "22 " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 235: mnemo = "xchg"; oper = "EB"; break;
            case 6: // mvi b, byte
                 val = mem.getCell(actPos++);
                 mnemo = "mvi B, "+String.format("%Xh", val);
                 oper = "06 " + String.format("%X", val);
                 break;
            case 14: // mvi c, byte
                 val = mem.getCell(actPos++);
                 mnemo = "mvi C, "+String.format("%Xh", val);
                 oper = "0E " + String.format("%X", val);
                 break;
            case 22: // mvi d, byte
                 val = mem.getCell(actPos++);
                 mnemo = "mvi D, "+String.format("%Xh", val);
                 oper = "16 " + String.format("%X", val);
                 break;
            case 30: // mvi e, byte
                 val = mem.getCell(actPos++);
                 mnemo = "mvi E, "+String.format("%Xh", val);
                 oper = "1E " + String.format("%X", val);
                 break;
            case 38: // mvi h, byte
                 val = mem.getCell(actPos++);
                 mnemo = "mvi H, "+String.format("%Xh", val);
                 oper = "26 " + String.format("%X", val);
                 break;
            case 46: // mvi l, byte
                 val = mem.getCell(actPos++);
                 mnemo = "mvi L, "+String.format("%Xh", val);
                 oper = "2E " + String.format("%X", val);
                 break;
            case 54: // mvi m, byte
                 val = mem.getCell(actPos++);
                 mnemo = "mvi M, "+String.format("%Xh", val);
                 oper = "36 " + String.format("%X", val);
                 break;
            case 62: // mvi a, byte
                 val = mem.getCell(actPos++);
                 mnemo = "mvi A, "+String.format("%Xh", val);
                 oper = "3E " + String.format("%X", val);
                 break;
            case 1: // lxi bc, dble
                 addr = mem.getCellWord(actPos);
                 mnemo = "lxi BC, "+String.format("%Xh", addr);
                 oper = "01 " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 17: // lxi de, dble
                 addr = mem.getCellWord(actPos);
                 mnemo = "lxi DE, "+String.format("%Xh", addr);
                 oper = "11 " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 33: // lxi hl, dble
                 addr = mem.getCellWord(actPos);
                 mnemo = "lxi HL, "+String.format("%Xh", addr);
                 oper = "21 " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 49: // lxi sp, dble
                 addr = mem.getCellWord(actPos);
                 mnemo = "lxi SP, "+String.format("%Xh", addr);
                 oper = "31 " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 249: mnemo = "sphl"; oper = "F9"; break;
            case 227: mnemo = "xthl"; oper = "E3"; break;
            case 193: mnemo = "pop BC"; oper = "C1"; break;
            case 209: mnemo = "pop DE"; oper = "D1"; break;
            case 225: mnemo = "pop HL"; oper = "E1"; break;
            case 241: mnemo = "pop PSW"; oper = "F1"; break;
            case 197: mnemo = "push BC"; oper = "C5"; break;
            case 213: mnemo = "push DE"; oper = "D5"; break;
            case 229: mnemo = "push HL"; oper = "E5"; break;
            case 245: mnemo = "push PSW"; oper = "F5"; break;
            case 219: // in port
                 val = mem.getCell(actPos++);
                 mnemo = "in "+String.format("%Xh", val);
                 oper = "DB " + String.format("%X", val);
                 break;
            case 211: // out port
                 val = mem.getCell(actPos++);
                 mnemo = "out "+String.format("%Xh", val);
                 oper = "D3 " + String.format("%X", val);
                 break;
            case 128: mnemo = "add B"; oper = "80"; break;
            case 129: mnemo = "add C"; oper = "81"; break;
            case 130: mnemo = "add D"; oper = "82"; break;
            case 131: mnemo = "add E"; oper = "83"; break;
            case 132: mnemo = "add H"; oper = "84"; break;
            case 133: mnemo = "add L"; oper = "85"; break;
            case 134: mnemo = "add M"; oper = "86"; break;
            case 135: mnemo = "add A"; oper = "87"; break;
            case 198: // adi byte
                 val = mem.getCell(actPos++);
                 mnemo = "adi "+String.format("%Xh", val);
                 oper = "C6 " + String.format("%X", val);
                 break;
            case 136: mnemo = "adc B"; oper = "88"; break;
            case 137: mnemo = "adc C"; oper = "89"; break;
            case 138: mnemo = "adc D"; oper = "8A"; break;
            case 139: mnemo = "adc E"; oper = "8B"; break;
            case 140: mnemo = "adc H"; oper = "8C"; break;
            case 141: mnemo = "adc L"; oper = "8D"; break;
            case 142: mnemo = "adc M"; oper = "8E"; break;
            case 143: mnemo = "adc A"; oper = "8F"; break;
            case 206: // aci byte
                 val = mem.getCell(actPos++);
                 mnemo = "aci "+String.format("%Xh", val);
                 oper = "CE " + String.format("%X", val);
                 break;
            case 9: mnemo = "dad BC"; oper = "09"; break;
            case 25: mnemo = "dad DE"; oper = "19"; break;
            case 41: mnemo = "dad HL"; oper = "29"; break;
            case 57: mnemo = "dad SP"; oper = "39"; break;
            case 144: mnemo = "sub B"; oper = "90"; break;
            case 145: mnemo = "sub C"; oper = "91"; break;
            case 146: mnemo = "sub D"; oper = "92"; break;
            case 147: mnemo = "sub E"; oper = "93"; break;
            case 148: mnemo = "sub H"; oper = "94"; break;
            case 149: mnemo = "sub L"; oper = "95"; break;
            case 150: mnemo = "sub M"; oper = "96"; break;
            case 151: mnemo = "sub A"; oper = "97"; break;
            case 214: // sui byte
                 val = mem.getCell(actPos++);
                 mnemo = "sui "+String.format("%Xh", val);
                 oper = "D6 " + String.format("%X", val);
                 break;
            case 152: mnemo = "sbb B"; oper = "98"; break;
            case 153: mnemo = "sbb C"; oper = "99"; break;
            case 154: mnemo = "sbb D"; oper = "9A"; break;
            case 155: mnemo = "sbb E"; oper = "9B"; break;
            case 156: mnemo = "sbb H"; oper = "9C"; break;
            case 157: mnemo = "sbb L"; oper = "9D"; break;
            case 158: mnemo = "sbb M"; oper = "9E"; break;
            case 159: mnemo = "sbb A"; oper = "9F"; break;
            case 222: // sbi byte
                 val = mem.getCell(actPos++);
                 mnemo = "sbi "+String.format("%Xh", val);
                 oper = "DE " + String.format("%X", val);
                 break;
            case 4: mnemo = "inr B"; oper = "04"; break;
            case 12: mnemo = "inr C"; oper = "0C"; break;
            case 20: mnemo = "inr D"; oper = "14"; break;
            case 28: mnemo = "inr E"; oper = "1C"; break;
            case 36: mnemo = "inr H"; oper = "24"; break;
            case 44: mnemo = "inr L"; oper = "2C"; break;
            case 52: mnemo = "inr M"; oper = "34"; break;
            case 60: mnemo = "inr A"; oper = "3C"; break;
            case 3: mnemo = "inx BC"; oper = "03"; break;
            case 19: mnemo = "inx DE"; oper = "13"; break;
            case 35: mnemo = "inx HL"; oper = "23"; break;
            case 51: mnemo = "inx SP"; oper = "33"; break;
            case 5: mnemo = "dcr B"; oper = "05"; break;
            case 13: mnemo = "dcr C"; oper = "0D"; break;
            case 21: mnemo = "dcr D"; oper = "15"; break;
            case 29: mnemo = "dcr E"; oper = "1D"; break;
            case 37: mnemo = "dcr H"; oper = "25"; break;
            case 45: mnemo = "dcr L"; oper = "2D"; break;
            case 53: mnemo = "dcr M"; oper = "35"; break;
            case 61: mnemo = "dcr A"; oper = "3D"; break;
            case 11: mnemo = "dcx BC"; oper = "0B"; break;
            case 27: mnemo = "dcx DE"; oper = "1B"; break;
            case 43: mnemo = "dcx HL"; oper = "2B"; break;
            case 59: mnemo = "dcx SP"; oper = "3B"; break;
            case 184: mnemo = "cmp B"; oper = "B8"; break;
            case 185: mnemo = "cmp C"; oper = "B9"; break;
            case 186: mnemo = "cmp D"; oper = "BA"; break;
            case 187: mnemo = "cmp E"; oper = "BB"; break;
            case 188: mnemo = "cmp H"; oper = "BC"; break;
            case 189: mnemo = "cmp L"; oper = "BD"; break;
            case 190: mnemo = "cmp M"; oper = "BE"; break;
            case 191: mnemo = "cmp A"; oper = "BF"; break;
            case 254: // cpi byte
                 val = mem.getCell(actPos++);
                 mnemo = "cpi "+String.format("%Xh", val);
                 oper = "FE " + String.format("%X", val);
                 break;
            case 39: mnemo = "daa"; oper = "27"; break;
            case 160: mnemo = "ana B"; oper = "A0"; break;
            case 161: mnemo = "ana C"; oper = "A1"; break;
            case 162: mnemo = "ana D"; oper = "A2"; break;
            case 163: mnemo = "ana E"; oper = "A3"; break;
            case 164: mnemo = "ana H"; oper = "A4"; break;
            case 165: mnemo = "ana L"; oper = "A5"; break;
            case 166: mnemo = "ana M"; oper = "A6"; break;
            case 167: mnemo = "ana A"; oper = "A7"; break;
            case 230: // ani byte
                 val = mem.getCell(actPos++);
                 mnemo = "ani "+String.format("%Xh", val);
                 oper = "E6 " + String.format("%X", val);
                 break;
            case 176: mnemo = "ora B"; oper = "B0"; break;
            case 177: mnemo = "ora C"; oper = "B1"; break;
            case 178: mnemo = "ora D"; oper = "B2"; break;
            case 179: mnemo = "ora E"; oper = "B3"; break;
            case 180: mnemo = "ora H"; oper = "B4"; break;
            case 181: mnemo = "ora L"; oper = "B5"; break;
            case 182: mnemo = "ora M"; oper = "B6"; break;
            case 183: mnemo = "ora A"; oper = "B7"; break;
            case 246: // ori byte
                 val = mem.getCell(actPos++);
                 mnemo = "ori "+String.format("%Xh", val);
                 oper = "F6 " + String.format("%X", val);
                 break;
            case 168: mnemo = "xra B"; oper = "A8"; break;
            case 169: mnemo = "xra C"; oper = "A9"; break;
            case 170: mnemo = "xra D"; oper = "AA"; break;
            case 171: mnemo = "xra E"; oper = "AB"; break;
            case 172: mnemo = "xra H"; oper = "AC"; break;
            case 173: mnemo = "xra L"; oper = "AD"; break;
            case 174: mnemo = "xra M"; oper = "AE"; break;
            case 175: mnemo = "xra A"; oper = "AF"; break;
            case 238: // xri byte
                 val = mem.getCell(actPos++);
                 mnemo = "xri "+String.format("%Xh", val);
                 oper = "EE " + String.format("%X", val);
                 break;
            case 47: mnemo = "cma"; oper = "2F"; break;
            case 7: mnemo = "rlc"; oper = "07"; break;
            case 15: mnemo = "rrc"; oper = "0F"; break;
            case 23: mnemo = "ral"; oper = "17"; break;
            case 31: mnemo = "rar"; oper = "1F"; break;
            case 55: mnemo = "stc"; oper = "37"; break;
            case 63: mnemo = "cmc"; oper = "3F"; break;
            case 233: mnemo = "pchl"; oper = "E9"; break;
            case 195: // jmp addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "jmp "+String.format("%Xh", addr);
                 oper = "C3 " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 194: // jnz addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "jnz "+String.format("%Xh", addr);
                 oper = "C2 " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 202: // jz addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "jz "+String.format("%Xh", addr);
                 oper = "CA " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 210: // jnc addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "jnc "+String.format("%Xh", addr);
                 oper = "D2 " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 218: // jc addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "jc "+String.format("%Xh", addr);
                 oper = "DA " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 226: // jpo addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "jpo "+String.format("%Xh", addr);
                 oper = "E2 " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 234: // jpe addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "jpe "+String.format("%Xh", addr);
                 oper = "EA " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 242: // jp addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "jp "+String.format("%Xh", addr);
                 oper = "F2 " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 250: // jm addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "jm "+String.format("%Xh", addr);
                 oper = "FA " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 205: // call addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "call "+String.format("%Xh", addr);
                 oper = "CD " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 196: // cnz addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "cnz "+String.format("%Xh", addr);
                 oper = "C4 " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 204: // cz addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "cz "+String.format("%Xh", addr);
                 oper = "CC " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 212: // cnc addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "cnc "+String.format("%Xh", addr);
                 oper = "D4 " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 220: // cc addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "cc "+String.format("%Xh", addr);
                 oper = "DC " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 228: // cpo addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "cpo "+String.format("%Xh", addr);
                 oper = "E4 " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 236: // cpe addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "cpe "+String.format("%Xh", addr);
                 oper = "EC " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 244: // cp addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "cp "+String.format("%Xh", addr);
                 oper = "F4 " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 252: // cm addr
                 addr = mem.getCellWord(actPos);
                 mnemo = "cm "+String.format("%Xh", addr);
                 oper = "FC " + String.format("%X %X", mem.getCell(actPos), mem.getCell(actPos+1));
                 actPos += 2; break;
            case 201: mnemo = "ret"; oper = "C9"; break;
            case 192: mnemo = "rnz"; oper = "C0"; break;
            case 200: mnemo = "rz"; oper = "C8"; break;
            case 208: mnemo = "rnc"; oper = "D0"; break;
            case 216: mnemo = "rc"; oper = "D8"; break;
            case 224: mnemo = "rpo"; oper = "E0"; break;
            case 232: mnemo = "rpe"; oper = "E8"; break;
            case 240: mnemo = "rp"; oper = "F0"; break;
            case 248: mnemo = "rm"; oper = "F8"; break;
            case 199: mnemo = "rst 0"; oper = "C7"; break;
            case 207: mnemo = "rst 1"; oper = "CF"; break;
            case 215: mnemo = "rst 2"; oper = "D7"; break;
            case 223: mnemo = "rst 3"; oper = "DF"; break;
            case 231: mnemo = "rst 4"; oper = "E7"; break;
            case 239: mnemo = "rst 5"; oper = "EF"; break;
            case 247: mnemo = "rst 6"; oper = "F7"; break;
            case 255: mnemo = "rst 7"; oper = "FF"; break;
            case 251: mnemo = "ei"; oper = "FB"; break;
            case 243: mnemo = "di"; oper = "F3"; break;
            case 118: mnemo = "hlt"; oper = "76"; break;
            case 0: mnemo = "nop"; oper = "00"; break;
            default: mnemo = "nezn�ma in�trukcia"; oper = Integer.toHexString((int)val);
        }
        returnSet.add(mnemo);returnSet.add(oper);returnSet.add(actPos);
        return returnSet;
    }

    // zisti adresu nasledujucej instrukcie
    public int getNextAddress(int memPos) {
        int actPos = memPos;
        short val;
        
        val = mem.getCell(actPos++);
        switch (val) {
            case 64: case 65: case 66: case 67: case 68: case 69: case 70: case 71: case 72: case 73: case 74: case 75: case 76:
            case 77: case 78: case 79: case 80: case 81: case 82: case 83: case 84: case 85: case 86: case 87: case 88: case 89:
            case 90: case 91: case 92: case 93: case 94: case 95: case 96: case 97: case 98: case 99: case 100: case 101: case 102:
            case 103: case 104: case 105: case 106: case 107: case 108: case 109: case 110: case 111: case 112: case 113: case 114:
            case 115: case 116: case 117: case 119: case 120: case 121: case 122: case 123: case 124: case 125: case 126: case 127:
            case 10: case 26: case 2: case 18: case 235: case 249: case 227: case 193: case 209: case 225: case 241: case 197: case 213:
            case 229: case 245: case 128: case 129: case 130: case 131: case 132: case 133: case 134: case 135: case 136: case 137:
            case 138: case 139: case 140: case 141: case 142: case 143: case 9: case 25: case 41: case 57: case 144: case 145: case 146:
            case 147: case 148: case 149: case 150: case 151: case 152: case 153: case 154: case 155: case 156: case 157: case 158:
            case 159: case 4: case 12: case 20: case 28: case 36: case 44: case 52: case 60: case 3: case 19: case 35: case 51: case 5:
            case 13: case 21: case 29: case 37: case 45: case 53: case 61: case 11: case 27: case 43: case 59: case 184: case 185:
            case 186: case 187: case 188: case 189: case 190: case 191: case 39: case 160: case 161: case 162: case 163: case 164:
            case 165: case 166: case 167: case 176: case 177: case 178: case 179: case 180: case 181: case 182: case 183: case 168:
            case 169: case 170: case 171: case 172: case 173: case 174: case 175: case 47: case 7: case 15: case 23: case 31: case 55:
            case 63: case 233: case 201: case 192: case 200: case 208: case 216: case 224: case 232: case 240: case 248: case 199: case 207:
            case 215: case 223: case 231: case 239: case 247: case 255: case 251: case 243: case 118: case 0: break;
            case 58: case 50: case 42: case 34: case 1: case 17: case 33: case 49: case 195: case 194: case 202: case 210: case 218:
            case 226: case 234: case 242: case 250: case 205: case 196: case 204: case 212: case 220: case 228: case 236: case 244: case 252:
                 actPos += 2; break;
            case 6: case 14: case 22: case 30: case 38: case 46: case 54: case 62: case 219: case 211: case 198: case 206: case 214:
            case 222: case 254: case 230: case 246: case 238: actPos++;  break;
            default: break;
        }
        return actPos;
    }
    
    
    /*
     * TODO:
     * 1. syntakticky analyzator (DONE)
     *
     * 2. Zotavenie zo syntaktickych chyb:
     *    procedury maju parameter - mnozinu pripustnych symbolov pre dane pravidlo (proceduru)
     *    existuju specialne procedury error a check
     *
     *    Implementacia mnoziny ps: - cez bitove operacie (ked nie je vela symbolov)
     *                              - pole
     *    (DONE)
     *
     * 3. prekladac (DONE)
     *
     * 4. disassembler na konkretnej pozicii (DONE)
     *
     */
       
}
