/*
 * Memory.java
 *
 * Created on Utorok, 2007, marec 6, 21:02
 *
 * KEEP IT SIMPLY STUPID
 */

package devices;

import java.lang.*;
import java.lang.Exception.*;

/**
 * Implementacia operacnej pamate ako zariadenia
 *
 * bunky su v type short (byte je signed...)
 * @author vbmacher
 */
public class Memory {
    private short[] mem;

    /**
     * Creates a new instance of Memory
     */
    public Memory(int size) {
        mem = new short[size];
    }
    
    public short getCell(int index)  throws IndexOutOfBoundsException {
        if (index >= mem.length) throw new IndexOutOfBoundsException();
        return (short)(mem[index] & 0xFF);
    }
    
    public void setCell(int index, short value) {
        if (index >= mem.length) return;
        mem[index] = (short)(value & 0xFF);
    }
//    public void setCell(int index, short value) throws IndexOutOfBoundsException {
//        if (index >= mem.length) throw new IndexOutOfBoundsException();
//        mem[index] = (short)(value & 0xFF);
//    }

    
    public int getCellWord(int index) throws IndexOutOfBoundsException {
        if (index >= mem.length)  throw new IndexOutOfBoundsException();
        if (index == mem.length-1) return mem[index];
        
        int low = mem[index] & 0xFF;
        int high = mem[index+1];
        return (int)((high << 8)| low);
    }
    
    public void setCellWord(int index, int value) {
        if (index >= mem.length) return;
        short high = (short)((value >>> 8) & 0xFF);
        short low = (short)(value & 0xFF);
        mem[index] = low;
        if (index < mem.length-1)
            mem[index+1] = high;
    }

//     public void setCellWord(int index, int value) throws IndexOutOfBoundsException {
//        if (index >= mem.length)  throw new IndexOutOfBoundsException();
//        short high = (short)((value >>> 8) & 0xFF);
//        short low = (short)(value & 0xFF);
//        mem[index] = low;
//        if (index < mem.length-1)
//            mem[index+1] = high;
//    }

    
    public void clearMemory() {
        for (int i = 0; i < mem.length; i++)
            mem[i] = 0;
    }
    
    public int getSize() {
        return mem.length;
    }

}
